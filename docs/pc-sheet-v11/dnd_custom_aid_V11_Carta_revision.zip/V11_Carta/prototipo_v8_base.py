#!/usr/bin/env python3
"""Independent, simulated A4 D&D character-sheet PDF - D-0076 exploratory V8.
This script deliberately has zero dependencies on the application's renderer."""
import os, math, json, re, itertools, collections, statistics
from pathlib import Path
from dataclasses import dataclass, field
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, Color
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics
from reportlab.lib.utils import simpleSplit

DIR=Path(__file__).resolve().parent/'_scratch_v8'; DIR.mkdir(parents=True,exist_ok=True)
MM=72/25.4
PW,PH=A4
M=lambda x:x*MM
COLORS={'ink':'#233c4d','blue':'#355f79','light':'#b2cbd5','fog':'#e8f3f5','ivory':'#f9f2e6','white':'#ffffff','line':'#90a8b4','soft':'#617988','title':'#254c64'}
C=lambda name:HexColor(COLORS.get(name,name))
labelpath='/usr/share/fonts/truetype/noto/NotoSansDisplay-CondensedBold.ttf'
valpath='/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf'
pdfmetrics.registerFont(TTFont('HeadingProxy',labelpath))
pdfmetrics.registerFont(TTFont('ValueProxy',valpath))
FHEAD='HeadingProxy'; FVAL='ValueProxy'
MARG=15; INNER=180; TOP=15; BOTTOM=282
CLASSIC=['Fuerza','Destreza','Constitución','Inteligencia','Sabiduría','Carisma']
SKILL_NAMES={'Fuerza':['Atletismo'],'Destreza':['Acrobacias','Juego de Manos','Sigilo'],'Constitución':[],
'Inteligencia':['Conoc. Arcano','Historia','Investigación','Naturaleza','Religión'],
'Sabiduría':['Medicina','Percepción','Perspicacia','Supervivencia','Trato con Animales'],
'Carisma':['Engaño','Interpretación','Intimidación','Persuasión']}

@dataclass
class Entry:
    id:str
    text:str
    extra:str=''
    origin:str=''
    value:str=''

@dataclass
class Fixture:
    name:str
    attrs:list
    skillmap:dict
    attacks:list
    traits:list
    ammo:list
    equipment:list
    coins:list
    special:list
    story:list
    spells:list
    notes:list
    book:list
    scenario:str
    variant:str
    @property
    def full_ids(self):
        all_lists=[self.attacks,self.traits,self.ammo,self.equipment,self.coins,self.special,self.story,self.spells,self.notes,self.book]
        out=[x.id for group in all_lists for x in group]
        out += [e.id for group in self.skillmap.values() for e in group]
        out += [a.id for a in self.attrs]
        return out

def mk_fixture(custom=2,stress=False,variant='A'):
    extra_attrs=['Suerte','Cordura','Honor'][:custom]
    attr_names=CLASSIC+extra_attrs
    attrs=[Entry(f'AT{i+1:02}',a,value=str([10,16,14,18,12,15,13,11,17][i]),extra=f'{[0,3,2,4,1,2,1,0,3][i]:+}') for i,a in enumerate(attr_names)]
    skillmap={}
    for a in CLASSIC:
        skillmap[a]=[Entry(f'SK{sum(len(SKILL_NAMES[k]) for k in CLASSIC[:CLASSIC.index(a)])+i+1:03}',sk,value=f'{(i%6)+1:+}',extra='P' if i%3==0 else '') for i,sk in enumerate(SKILL_NAMES[a])]
    counter=19
    for i,a in enumerate(extra_attrs):
        n=([8,8,7][i] if stress else [2,3,3][i]); gg=[]
        for j in range(n):
            gg.append(Entry(f'SK{counter:03}',f'{a}: {("Impulso","Sello","Equilibrio","Lectura","Instinto","Resistencia","Memoria","Voluntad")[j%8]}',value=f'{(i+j)%7:+}',extra='P' if j%2 else ''))
            counter+=1
        skillmap[a]=gg
    attacks=[Entry(f'AK{i+1:03}',f'{["Espada larga","Arco élfico","Rayo lunar","Puñal de plata","Golpe místico"][i%5]} {i//5+1}',value=f'+{3+i%6}',extra=f'{1+i%4}d{6+i%3*2} / {"corte" if i%2 else "fuerza"}') for i in range(24 if stress else 3)]
    traits=[Entry(f'TR{i+1:03}',f'{["Rasgo de Clase","Rasgo de Raza","Dote","Origen","Otro"][i%5]} - {("Disciplina","Ecos arcanos","Tenacidad","Vigilia","Aliento largo")[i%5]} {i+1}') for i in range(26 if stress else 7)]
    ammo=[Entry(f'AM{i+1:03}',f'{["Flechas","Virotes","Dardos","Proyectiles de energía"][i%4]} {i+1}',value=str(12+i*3)) for i in range(7 if stress else 2)]
    equipment=[Entry(f'EQ{i+1:03}',f'{["Cuerda de seda","Antorcha","Botella de tinta","Ración","Ganzúas","Pergamino sellado","Frasco"][i%7]} {i//7+1}',value=str(1+(i%6))) for i in range(58 if stress else 11)]
    denominations=['Platino','Oro','Electro','Plata','Cobre']+[f'Moneda custom {i}' for i in range(1,13)]
    coins=[Entry(f'CO{i+1:03}',denominations[i],value=str(0 if i%5==0 else 7+i*17)) for i in range(17 if stress else 6)]
    special=[Entry(f'ES{i+1:03}',f'{["Anillo","Amuleto","Guante","Arma","Bolsa","Cuello"][i%6]} encantado {i+1}',origin=['Mano der.','Mano izq.','Cuello','Mochila','Mano der.','Cintura'][i%6],extra=f'Objeto vinculado a {"defensa" if i%2 else "luz"}; uso declarado por quien dirige') for i in range(21 if stress else 5)]
    paragraph_seed=['Creció en una ciudad de canales y aprendió a escuchar las voces que atravesaban sus puentes.',
        'Su primera expedición dejó una deuda con una orden antigua; recuerda cada juramento, pero no siempre su causa.',
        'Cuando conoció los mapas imposibles prometió conservarlos sin revelar los refugios de sus aliados.',
        'Su historia incluye alianzas, pérdidas y decisiones que todavía pueden cambiar durante la campaña.']
    story=[Entry(f'HI{i+1:03}',paragraph_seed[i%4]+(' Conserva en su diario un episodio aún por resolver.' if i%3==0 else '')) for i in range(22 if stress else 4)]
    spells=[]
    spellnames=['Luz','Escudo','Proyectil mágico','Paso brumoso','Disipar magia','Bola de fuego','Vuelo','Rayo de escarcha','Detectar magia','Puerta dimensional','Resistencia','Mano de mago']
    for i in range(144 if stress else 19):
        lv=([0]*9+[1]*17+[2]*21+[3]*24+[4]*19+[5]*18+[6]*15+[7]*10+[8]*7+[9]*4)[i] if stress else ([0]*3+[1]*5+[2]*4+[3]*4+[4]*3)[i]
        src=['CL','RA','DO'][i%3]
        spells.append(Entry(f'SP{i+1:03}',f'{spellnames[i%len(spellnames)]} {i//len(spellnames)+1 if stress else ""}'.strip(),origin=src,extra=['PREP','NO PREP','—'][i%3],value=str(lv)))
    notes=[Entry(f'NO{i+1:03}',f'Nota {i+1}: '+paragraph_seed[i%4]+' La pista puede ser usada en una sesión posterior. '*2) for i in range(9 if stress else 2)]
    book=[Entry(f'LI{i+1:03}',f'{spellnames[(i*2)%len(spellnames)]} {i+1}',value=str(i%9+1),origin=['Abjuración','Evocación','Ilusión','Transmutación'][i%4],extra=('Esta descripción ficticia se conserva íntegra; la criatura objetivo se beneficia de una transformación limitada y comprobable. '+paragraph_seed[i%4]+' ')*(2+i%3)) for i in range(8 if stress else 3)]
    f=Fixture('Mara de los Siete Umbrales' if stress else 'Ariadna del Alba',attrs,skillmap,attacks,traits,ammo,equipment,coins,special,story,spells,notes,book, 'EXTREMO FICTICIO' if stress else f'ORDINARIO 6+{custom}',variant)
    assert len(f.full_ids)==len(set(f.full_ids)), 'fixture duplicate'
    return f

# top-coordinate canvas support

def line(c,x1,y1,x2,y2,color='line',width=.36):
    c.setStrokeColor(C(color));c.setLineWidth(width);c.line(M(x1),PH-M(y1),M(x2),PH-M(y2))
def rect(c,x,y,w,h,fill=None,stroke='line',sw=.35,r=0):
    c.setLineWidth(sw);c.setStrokeColor(C(stroke) if stroke else C('white'))
    c.setFillColor(C(fill) if fill else C('white'))
    if r:c.roundRect(M(x),PH-M(y+h),M(w),M(h),M(r),fill=int(fill is not None),stroke=int(stroke is not None))
    else:c.rect(M(x),PH-M(y+h),M(w),M(h),fill=int(fill is not None),stroke=int(stroke is not None))
def poly(c,coords,fill='white',stroke='line',sw=.5):
    p=c.beginPath();p.moveTo(M(coords[0][0]),PH-M(coords[0][1]));
    for x,y in coords[1:]:p.lineTo(M(x),PH-M(y))
    p.close();c.setFillColor(C(fill));c.setStrokeColor(C(stroke));c.setLineWidth(sw);c.drawPath(p,fill=1,stroke=1)
def txt(c,x,y,s,size=7.2,font=FVAL,color='ink',align='left'):
    c.setFillColor(C(color));c.setFont(font,size)
    if align=='right':c.drawRightString(M(x),PH-M(y),str(s))
    elif align=='center':c.drawCentredString(M(x),PH-M(y),str(s))
    else:c.drawString(M(x),PH-M(y),str(s))
def text_width(s,size=7,font=FVAL):return pdfmetrics.stringWidth(str(s),font,size)/MM

def fit_size(s,width,start=7.4,minsize=5.8,font=FVAL):
    size=start
    while size>minsize and text_width(s,size,font)>width:size-=.2
    return size

def clipstring(s,w,size=7,font=FVAL):
    if text_width(s,size,font)<=w:return s
    out=''
    for ch in s:
        if text_width(out+ch+'…',size,font)>w:break
        out+=ch
    return out+'…'

def wraptext(s,w,size=7.1,font=FVAL):
    paragraphs=[]
    for part in s.split('\n'):
        if part.strip():paragraphs.extend(simpleSplit(part,font,size,M(w)))
        else:paragraphs.append('')
    return paragraphs

def check(c,x,y,size=3.3,marked=False):
    rect(c,x,y,size,size,fill='white',stroke='blue',sw=.48,r=.45)
    if marked:
        line(c,x+.55,y+1.55,x+1.3,y+size-.55,'blue',.95)
        line(c,x+1.3,y+size-.55,x+size-.45,y+.45,'blue',.95)

def cartouche(c,x,y,w,h,fill='white'):
    # D-0076 C2c: small chamfers / clipped-corner cartouche
    k=min(2.2,h*.25,w*.12)
    poly(c,[(x+k,y),(x+w-k,y),(x+w,y+k),(x+w,y+h-k),(x+w-k,y+h),(x+k,y+h),(x,y+h-k),(x,y+k)],fill,'blue',.56)
    line(c,x+3,y+1.2,x+w-3,y+1.2,'light',.35)

def band(c,x,y,w,h,index):
    rect(c,x,y,w,h,'fog' if index%2==0 else 'ivory',None)
    line(c,x,y+h,x+w,y+h,'line',.27)

def section(c,x,y,w,title,sub=None):
    cartouche(c,x,y,w,7.6,'fog')
    txt(c,x+3,y+5.7,title.upper(),9,FHEAD,'title')
    if sub:txt(c,x+w-2,y+5.2,sub,6.3,FVAL,'soft','right')
    return y+8.5

def ruled(c,x,y,w,n=4,h=7):
    for i in range(n):band(c,x,y+i*h,w,h,i)
    return y+n*h

def topframe(c,name,page_no,total,kind,scenario):
    rect(c,10.0,9.5,190,278,None,'blue',.72,r=2)
    rect(c,11.6,11.1,186.8,274.8,None,'light',.34,r=1.2)
    txt(c,16,19,'D&D',16,FHEAD,'blue')
    line(c,39,16.8,39,23.6,'light',.55)
    txt(c,42,19.2,'HOJA DE PERSONAJE  /  PRUEBA V8',9.1,FHEAD,'title')
    txt(c,194,19.0,kind,6.8,FHEAD,'soft','right')
    line(c,15,23.5,195,23.5,'light',.7)
    txt(c,16,28.1,name,10.2,FHEAD,'title')
    txt(c,194,27.4,scenario,6.7,FHEAD,'soft','right')
    line(c,15,279.5,195,279.5,'light',.6)
    txt(c,16,284.0,'DOCUMENTO DE MUESTRA · FICCION · NO PROVIENE DE LA APP',6,FVAL,'soft')
    txt(c,194,284,'PÁG. %02d / %02d'%(page_no,total),7.2,FHEAD,'blue','right')


def simple_row(c,x,y,w,entry,kind,h=6.2,idx=0,registry=None):
    band(c,x,y,w,h,idx)
    ty=y+h*.68
    if kind=='skill':
        if entry.id.startswith('AT'):
            txt(c,x+1.7,ty,'ATRIBUTO  '+entry.text.upper(),7.5,FHEAD,'title')
            cartouche(c,x+w-25,y+1.1,12,h-2.0)
            txt(c,x+w-19,y+h*.70,entry.value,8.1,FHEAD,'blue','center')
            txt(c,x+w-3,ty,entry.extra,7.3,FHEAD,'blue','right')
        else:
            check(c,x+.9,y+(h-3.15)/2,3.15,False)
            txt(c,x+5.3,ty,clipstring(entry.text,w-20,6.55),6.55)
            txt(c,x+w-1.4,ty,entry.value or '—',6.7,FVAL,'blue','right')
    elif kind=='attack':
        txt(c,x+1.7,ty,clipstring(entry.text,w*.53-2,6.8),6.8)
        txt(c,x+w*.60,ty,entry.value,6.7,FVAL,'blue','center')
        txt(c,x+w-1.7,ty,clipstring(entry.extra,w*.29,6.5),6.5,FVAL,'ink','right')
        line(c,x+w*.53,y,x+w*.53,y+h,'line',.32);line(c,x+w*.67,y,x+w*.67,y+h,'line',.32)
    elif kind=='ammo':
        txt(c,x+1.5,y+3.9,clipstring(entry.text,w-57,6.2),6.2)
        if int(entry.value)<=20:
            for n in range(int(entry.value)):
                check(c,x+w-49+(n%10)*4.6,y+(0.8 if n<10 else 4.8),2.85)
        else:txt(c,x+w-2,y+5.8,'____ / '+entry.value,7,FVAL,'blue','right')
    elif kind=='coin':
        txt(c,x+1.8,ty,clipstring(entry.text,w-19,6.6),6.6)
        txt(c,x+w-1.5,ty,entry.value,7,FVAL,'blue','right')
    elif kind=='equipment':
        txt(c,x+1.8,ty,clipstring(entry.text,w-12,6.65),6.65)
        txt(c,x+w-1.5,ty,entry.value,7,FVAL,'blue','right')
    elif kind=='special':
        check(c,x+w-4.7,y+1.2,3)
        txt(c,x+1.5,y+3.8,clipstring(entry.origin,w*.24,6.4),6.4,FVAL,'blue')
        txt(c,x+w*.25,y+3.8,clipstring(entry.text,w*.68,6.7),6.7)
        if h>=13:
            for j,L in enumerate(wraptext(entry.extra,w-6,6.15)):
                txt(c,x+1.5,y+7.3+j*3.55,L,6.15,FVAL,'soft')
        else:txt(c,x+1.5,y+h-1.4,clipstring(entry.extra,w-8,5.9),5.9,FVAL,'soft')
    elif kind=='story':
        lines=wraptext(entry.text,w-3,6.3)
        for j,L in enumerate(lines):
            yy=y+4.0+j*3.55
            if yy<y+h-.2:txt(c,x+1.8,yy,L,6.3)
    else:
        txt(c,x+1.8,ty,clipstring(entry.text,w-3.6,6.9),6.9)
    if registry is not None:registry.append(entry.id)

def attr_group(c,x,y,w,attr,skills,registry,idx):
    n=len(skills)
    head=10.6
    if idx%2==0:rect(c,x,y,w,head,'fog',None)
    else:rect(c,x,y,w,head,'ivory',None)
    txt(c,x+1.5,y+3.9,attr.text.upper(),8.4,FHEAD,'title')
    cartouche(c,x+2,y+4.8,21,5.5)
    txt(c,x+12.5,y+8.6,attr.value,10.4,FHEAD,'blue','center')
    c.setStrokeColor(C('blue'));c.setFillColor(C('white'));c.setLineWidth(.7)
    c.ellipse(M(x+18.7),PH-M(y+11),M(x+31.7),PH-M(y+5.1),fill=1,stroke=1)
    txt(c,x+25.2,y+9.5,attr.extra,7.0,FHEAD,'blue','center')
    txt(c,x+33,y+8.5,'SALV.',6.1,FHEAD,'soft');check(c,x+44,y+5.6,3)
    txt(c,x+w-1.4,y+8.3,attr.extra,7.1,FVAL,'blue','right')
    registry.append(attr.id)
    for i,s in enumerate(skills):simple_row(c,x,y+head+i*5.0,w,s,'skill',5,idx+i,registry)
    return head+len(skills)*5.0

# Includes physical page references after pagination, never placeholder page numbers.
MODULE_NAME={'skill':'HABILIDADES','attack':'ATAQUES','trait':'RASGOS','equipment':'EQUIPO','coin':'TESORO','special':'EQUIPO ESPECIAL','story':'HISTORIA','ammo':'MUNICIONES'}
ORIGIN={'skill':'P1','attack':'P1','trait':'P1/P2/P3','equipment':'P2','coin':'P2','special':'P2','story':'P3','ammo':'P1'}
H={'skill':5.4,'attack':6.8,'trait':5.8,'equipment':6.0,'coin':6.,'special':9.2,'story':13.1,'ammo':9.0}

@dataclass
class Tile:
    kind:str
    entries:list
    h:float
    wtype:str='half'
    x:float=0
    y:float=0
    w:float=0
    page:int=0

def rowheight(kind,e,width):
    if kind=='skill' and e.id.startswith('AT'):return 9.5
    if kind=='story':return max(11,4.8+len(wraptext(e.text,width-4,6.3))*3.55)
    if kind=='special':return max(10,6.4+len(wraptext(e.extra,width-6,6.15))*3.55)
    return H[kind]

def tiles_for(spills,mode):
    out=[]
    for kind,entries in spills.items():
        if not entries:continue
        wide=(mode=='vertical' or (mode=='mixto' and kind in ('attack','special','story')))
        rows=6 if kind in ('special','story') else 10
        if wide:rows=7 if kind in ('special','story') else 10
        for i in range(0,len(entries),rows):
            chunk=entries[i:i+rows]
            available_width=178 if wide else 86.5
            out.append(Tile(kind,chunk,8+sum(rowheight(kind,e,available_width) for e in chunk)+2,'wide' if wide else 'half'))
    return out

def pack_c2(spills,mode):
    tiles=tiles_for(spills,mode)
    pages=[]; current=[]; y_left=y_right=39.0; page=0
    def nextpage():
        nonlocal current,y_left,y_right,page
        if current:pages.append(current)
        current=[];y_left=y_right=39;page+=1
    for tile in tiles:
        if tile.h>233:raise ValueError('tile exceeds C2 frame')
        if mode=='vertical':
            if y_left+tile.h>273:nextpage()
            tile.x=16;tile.y=y_left;tile.w=178
            y_left+=tile.h+2;y_right=y_left
        elif mode=='dos_columnas':
            # keep column order: fill first column before second; C2 modules may share pages.
            if y_left+tile.h<=272:
                tile.x=16;tile.y=y_left;tile.w=86.5;y_left+=tile.h+2
            elif y_right+tile.h<=272:
                tile.x=107.5;tile.y=y_right;tile.w=86.5;y_right+=tile.h+2
            else:
                nextpage();tile.x=16;tile.y=y_left;tile.w=86.5;y_left+=tile.h+2
        else:
            if tile.wtype=='wide':
                cursor=max(y_left,y_right)
                if cursor+tile.h>272:nextpage();cursor=39
                tile.x=16;tile.y=cursor;tile.w=178;y_left=y_right=cursor+tile.h+2
            else:
                shorter='left' if y_left<=y_right else 'right'; yy=min(y_left,y_right)
                if yy+tile.h>272:
                    other='right' if shorter=='left' else 'left'; otherY=y_right if other=='right' else y_left
                    if otherY+tile.h<=272:shorter=other;yy=otherY
                    else:nextpage();shorter='left';yy=39
                tile.x=16 if shorter=='left' else 107.5;tile.y=yy;tile.w=86.5
                if shorter=='left':y_left=yy+tile.h+2
                else:y_right=yy+tile.h+2
        tile.page=page;current.append(tile)
    if current:pages.append(current)
    geometric=sum(t.w*t.h for t in tiles)/(len(pages)*178*233) if pages else 0
    # half-width tiles contain fewer chars/row; record as occupancy not legibility score
    return pages,{'pages':len(pages),'tiles':len(tiles),'items':sum(len(t.entries) for t in tiles),'geometric_occupancy':round(geometric*100,2),'mode':mode}

def paper_record(c,entry,x,y,w,kind,idx,registry):
    simple_row(c,x,y,w,entry,kind,H[kind],idx,registry)

def draw_tile(c,tile,registry,nextprev=None):
    x,y,w=tile.x,tile.y,tile.w
    cartouche(c,x,y,w,7.5,'fog')
    txt(c,x+2,y+5.1,MODULE_NAME[tile.kind],8.25,FHEAD,'title')
    if nextprev:
        txt(c,x+w-1.5,y+5.1,nextprev,5.7,FHEAD,'blue','right')
    yy=y+8
    for idx,e in enumerate(tile.entries):
        h=rowheight(tile.kind,e,w)
        simple_row(c,x,yy,w,e,tile.kind,h,idx,registry);yy+=h


def base1(c,f,registry,spill,refs,variant):
    # compact identity and portrait area
    cartouche(c,16,33,27,26,'white')
    # generic silhouette: simple minimal faceless portrait, not a background illustration
    c.setStrokeColor(C('light'));c.setFillColor(C('fog'))
    c.circle(M(29.5),PH-M(40.9),M(4.0),stroke=1,fill=1)
    c.ellipse(M(22.7),PH-M(56.7),M(36.3),PH-M(45),fill=1,stroke=1)
    txt(c,30,59.5,'RETRATO',5.1,FHEAD,'soft','center')
    cartouche(c,47,33,102,12,'fog');txt(c,50,37.7,'PERSONAJE',6,FHEAD,'soft');txt(c,50,42,f.name,12.2,FHEAD,'title')
    cartouche(c,151,33,43,12);txt(c,153,37.8,'CLASE / NIVEL',6,FHEAD,'soft');txt(c,153,42,'Maga exploradora / 8',7.5,FVAL)
    cartouche(c,47,47,61.5,12);txt(c,49,51.4,'JUGADOR',6,FHEAD,'soft');txt(c,49,56,'Personaje de prueba',7,FVAL)
    cartouche(c,110,47,50,12);txt(c,112,51.4,'RAZA 60 %',6,FHEAD,'soft');txt(c,112,56,'Humana',7,FVAL)
    cartouche(c,162,47,32,12);txt(c,164,51.4,'ALINEAMIENTO',5.8,FHEAD,'soft');txt(c,164,56,'Neutral',7,FVAL)
    x=16;w=69;leftY=63
    section(c,x,leftY,w,'ATRIBUTOS · '+variant,'P1 / variantes A-B')
    reg={a.text:a for a in f.attrs}
    if variant=='A':
        yy=leftY+9
        for i,a in enumerate(f.attrs):
            skills=f.skillmap[a.text]
            # Reserve a score cartouche for every remaining attribute before allocating skills.
            cap=274-yy-10.6*(len(f.attrs)-i-1)
            head=10.6
            if cap<head:
                spill['skill'].append(a)
                spill['skill']+=skills
                continue
            amount=min(len(skills),max(0,int((cap-head)/5)))
            if a.text in CLASSIC and amount<len(skills):
                spill['skill']+=skills[amount:]
            elif a.text not in CLASSIC and amount<len(skills):
                spill['skill']+=skills[amount:]
            yy+=attr_group(c,x,yy,w,a,skills[:amount],registry,i)
    else:
        yy=leftY+9
        yy=section(c,x,yy,w,'PUNTUACIONES Y MODS.')
        for i,a in enumerate(f.attrs):
            if yy+9.5>272:spill['skill'].append(a);continue
            band(c,x,yy,w,9.4,i)
            txt(c,x+2,yy+5.7,a.text.upper(),7.3,FHEAD,'title')
            cartouche(c,x+35,yy+1.5,12,6.5);txt(c,x+41,yy+6.1,a.value,8.4,FHEAD,'blue','center')
            c.setStrokeColor(C('blue'));c.setFillColor(C('white'));c.ellipse(M(x+45),PH-M(yy+8.9),M(x+57.5),PH-M(yy+3.3),fill=1,stroke=1)
            txt(c,x+51.1,yy+7.2,a.extra,7.1,FHEAD,'blue','center')
            registry.append(a.id);yy+=9.4
        yy+=2;yy=section(c,x,yy,w,'SALVACIONES')
        for i,a in enumerate(f.attrs):
            if yy+4.6>272:break
            band(c,x,yy,w,4.6,i);check(c,x+1.2,yy+.65,3)
            txt(c,x+5.6,yy+3.45,clipstring(a.text,w-16,6.3),6.3)
            txt(c,x+w-2,yy+3.45,a.extra,6.3,FVAL,'blue','right');yy+=4.6
        yy+=2;yy=section(c,x,yy,w,'HABILIDADES')
        entries=[e for a in f.attrs for e in f.skillmap[a.text]]
        for i,e in enumerate(entries):
            if yy+5>273:spill['skill'].append(e)
            else:simple_row(c,x,yy,w,e,'skill',5,i,registry);yy+=5
    # full right P1 integrated
    rx=89;rw=105;yy=63
    yy=section(c,rx,yy,rw,'COMBATE Y SUPERVIVENCIA')
    stats=[('CA','16'),('INICIATIVA','+3'),('VELOCIDAD','9 m'),('COMPETENCIA','+3'),('INSPIRACIÓN','□'),('DADOS DE GOLPE','8d8')]
    for row in range(2):
        for j in range(3):
            xx=rx+j*(rw/3);wcell=rw/3-1.1
            cartouche(c,xx,yy+row*13.5,wcell,12.5)
            txt(c,xx+2,yy+row*13.5+3.9,stats[row*3+j][0],6.0,FHEAD,'soft')
            txt(c,xx+wcell/2,yy+row*13.5+10.1,stats[row*3+j][1],10.2,FHEAD,'blue','center')
    yy+=28
    for j,title in enumerate(('PV ACTUALES','PV MÁXIMOS')):
        xx=rx+j*(rw/2);cartouche(c,xx,yy,rw/2-1.1,12.5)
        txt(c,xx+2,yy+4,title,6.5,FHEAD,'soft');txt(c,xx+rw/4,yy+10.1,'46' if j==0 else '50',10.5,FHEAD,'blue','center')
    yy+=14.2
    yy=section(c,rx,yy,rw,'ATAQUES','3 columnas')
    band(c,rx,yy,rw,4.8,0)
    txt(c,rx+2,yy+3.5,'ARMA / ATAQUE / CONJURO',5.9,FHEAD,'blue')
    txt(c,rx+66,yy+3.5,'BON.',5.9,FHEAD,'blue')
    txt(c,rx+104,yy+3.5,'DAÑO / TIPO',5.9,FHEAD,'blue','right')
    yy+=4.8
    take=min(5,len(f.attacks))
    for i,e in enumerate(f.attacks[:take]):simple_row(c,rx,yy+i*5.7,rw,e,'attack',5.7,i,registry)
    if not take:ruled(c,rx,yy,rw,5,5.7)
    spill['attack']+=f.attacks[take:]
    yy+=max(take,3)*5.7+1.8
    yy=section(c,rx,yy,rw,'RASGOS Y ATRIBUTOS','solo nombres mecánicos')
    take=min(4,len(f.traits))
    for i,e in enumerate(f.traits[:take]):simple_row(c,rx,yy+i*5.4,rw,e,'trait',5.4,i,registry)
    yy+=max(take,3)*5.4+1.6
    yy=section(c,rx,yy,rw,'LANZAMIENTO DE CONJUROS','siempre presente')
    for i,(t,v) in enumerate([('APTITUD MÁGICA','INT'),('CD SALVACIÓN','15'),('BON. ATAQUE','+7')]):
        xx=rx+i*(rw/3);cartouche(c,xx,yy,rw/3-1.0,10)
        txt(c,xx+1.5,yy+3.8,t,5.85,FHEAD,'soft');txt(c,xx+rw/6,yy+8.2,v,8.2,FHEAD,'blue','center')
    yy+=12
    # 3 x 3 levels; not fixed at four boxes (manual demo markers intentionally unlabeled)
    for row in range(3):
        for j in range(3):
            lv=row*3+j+1;xx=rx+j*(rw/3)
            band(c,xx,yy+row*7.2,rw/3-.7,7.2,row+j)
            txt(c,xx+2,yy+row*7.2+4.8,f'N{lv}',7,FHEAD,'blue')
            for k in range([4,3,3,4,2,2,3,1,2][lv-1]):check(c,xx+11+k*5.1,yy+row*7.2+1.7,3.1)
    yy+=23.3
    yy=section(c,rx,yy,rw,'MUNICIONES','marcar a mano')
    rem=max(1,math.floor((273-yy)/7.2))
    show=min(2,rem,len(f.ammo))
    for i,e in enumerate(f.ammo[:show]):
        band(c,rx,yy+i*7.0,rw,7,i)
        txt(c,rx+2,yy+i*7+4.5,clipstring(e.text,43,6.4),6.4)
        if int(e.value)<=20:
            for n in range(int(e.value)):check(c,rx+49+(n%10)*5.1,yy+i*7+(.4 if n<10 else 3.8),2.6)
        else:txt(c,rx+103,yy+i*7+4.5,f'____ / {e.value}',7.0,FVAL,'blue','right')
        registry.append(e.id)
    spill['ammonotused']=[]
    # ammo may not migrate to C2 if crowded; C2 needs it as a separate type with own format
    spill.setdefault('ammo',[]).extend(f.ammo[show:])
    if len(f.ammo)==0:band(c,rx,yy,rw,7,0);txt(c,rx+2,yy+4.8,'Tipo: __________________',6.8)
    return


def base2(c,f,registry,spill):
    L=16;LW=86;R=107;RW=87;yy=34
    yy=section(c,L,yy,LW,'EQUIPO','OBJETO / CANTIDAD')
    n=min(14,len(f.equipment));
    for i,e in enumerate(f.equipment[:n]):simple_row(c,L,yy+i*6.6,LW,e,'equipment',6.6,i,registry)
    if not n:ruled(c,L,yy,LW,13,6.6)
    spill['equipment']+=f.equipment[n:]
    yy+=max(n,13)*6.6+2
    yy=section(c,L,yy,LW,'TESORO','DENOMINACIÓN / CANTIDAD')
    n=min(8,len(f.coins));subw=(LW-1)/2
    for i,e in enumerate(f.coins[:n]):
        xx=L+(i%2)*subw;yyy=yy+(i//2)*7.0
        simple_row(c,xx,yyy,subw-1,e,'coin',7,i,registry)
    if n<6:
        for i in range(n,6):ruled(c,L+(i%2)*subw,yy+(i//2)*7,subw-1,1,7)
    spill['coin']+=f.coins[n:]
    ryt=34;ryt=section(c,R,ryt,RW,'RASGOS Y ATRIBUTOS','continuación P1')
    other=f.traits[4:]
    n=min(18,len(other));
    for i,e in enumerate(other[:n]):simple_row(c,R,ryt+i*6.4,RW,e,'trait',6.4,i,registry)
    if not n:ruled(c,R,ryt,RW,8,6.4)
    spill['trait']+=other[n:]
    yy2=175
    yy2=section(c,16,yy2,178,'EQUIPO ESPECIAL','UBICACIÓN / NOMBRE / DESCRIPCIÓN / ACTIVO')
    # separate full-width tabular layout
    for i,e in enumerate(f.special[:8]):simple_row(c,16,yy2+i*10.5,178,e,'special',10.5,i,registry)
    if len(f.special)<8:
        for i in range(len(f.special),8):
            band(c,16,yy2+i*10.5,178,10.5,i)
            txt(c,18,yy2+i*10.5+4.2,'Ubicación: __________  Nombre: __________________________  Descripción: _____________________',6.6,FVAL,'soft')
            check(c,189,yy2+i*10.5+3,3.2)
    spill['special']+=f.special[8:]


def base3(c,f,registry,spill,extra_traits):
    L=16;LW=112;R=132;RW=62
    y=35;y=section(c,L,y,LW,'TRASFONDO Y PERFIL NARRATIVO','página siempre presente')
    for title,val in [('TRASFONDO','Cartógrafa de los umbrales'),('RELIGIÓN / FE','Culto del faro'),('RASGOS DE PERSONALIDAD','Observadora y paciente'),('IDEALES','La verdad precede a la gloria'),('VÍNCULOS','Juramento con el grupo'),('DEFECTOS','Desconfía de los acertijos fáciles')]:
        band(c,L,y,LW,9.4,round(y))
        txt(c,L+2,y+3.4,title,6.3,FHEAD,'soft')
        txt(c,L+2,y+7.6,val,7.1,FVAL,'ink');y+=9.4
    y+=2;y=section(c,L,y,LW,'HISTORIA','renglones mantenidos')
    # Each simulated prose record intentionally occupies multiple writing lines
    n=min(10,len(f.story))
    for i,e in enumerate(f.story[:n]):
        simple_row(c,L,y+i*12.2,LW,e,'story',12.2,i,registry)
    spill['story']+=f.story[n:]
    end=y+max(n,8)*12.2
    if end<273:ruled(c,L,end,LW,int((273-end)/7),7)
    ry=35;ry=section(c,R,ry,RW,'RASGOS','sin duplicar')
    n=min(4,len(extra_traits));
    for i,e in enumerate(extra_traits[:n]):simple_row(c,R,ry+i*6.1,RW,e,'trait',6.1,i,registry)
    if not n:ruled(c,R,ry,RW,6,7)
    spill['trait']+=extra_traits[n:]
    ry+=max(n,6)*6.1+4
    ry=section(c,R,ry,RW,'HISTORIA MANUSCRITA')
    ruled(c,R,ry,RW,int((272-ry)/7),7)


def plan_spell_pages(spells):
    # Sequential level order in three reading columns, with one-line level header.
    pages=[];page=[];col=0;y=53;last_level=None
    for lv in range(10):
        group=[e for e in spells if int(e.value)==lv]
        if not group:continue
        for e in group:
            needhead=(last_level!=lv or (page and page[-1][0]=='reset'))
            if y+ (6.8 if needhead else 0) + 5.8>270:
                col+=1;y=53;last_level=None;needhead=True
                if col==3:
                    pages.append(page);page=[];col=0
            if last_level!=lv:
                page.append(('level',col,y,lv));y+=7.4
            page.append(('spell',col,y,e));y+=5.6
            last_level=lv
    if page:pages.append(page)
    return pages

def spellpage(c,f,items,registry,pn,total):
    topframe(c,f.name,pn,total,'LISTA RÁPIDA DE CONJUROS',f.scenario)
    section(c,16,34,178,'REFERENCIA MÁGICA','FICCIÓN · DATOS NO VERIFICADOS EN LA APP')
    for i,(lbl,val) in enumerate([('APTITUD','INT'),('CD DE SALVACIÓN','15'),('ATAQUE MÁGICO','+7')]):
        xx=16+i*59.3;cartouche(c,xx,42,58,8)
        txt(c,xx+2,47,lbl,6.2,FHEAD,'soft');txt(c,xx+54,47,val,7.3,FHEAD,'blue','right')
    colw=56.4
    for kind,j,y,data in items:
        x=16+j*61
        if kind=='level':
            band(c,x,y,colw,7,0)
            txt(c,x+1.3,y+4.75,f'NIVEL {data}' if data else 'TRUCOS · 0',7,FHEAD,'title')
            if data:
                txt(c,x+colw-1.2,y+4.75,'ESP: ___  GAST: □ □ +' ,6,FHEAD,'blue','right')
        else:
            e=data;band(c,x,y,colw,5.6,int(e.value))
            check(c,x+.65,y+1.3,2.8,False)
            txt(c,x+4.3,y+4.05,clipstring(e.text,colw-18,6.2),6.2)
            txt(c,x+colw-1.0,y+4.05,e.origin+'/'+e.extra,5.45,FHEAD,'blue','right')
            registry.append(e.id)


def draw_notes(c,f,notes,registry,pn,total):
    topframe(c,f.name,pn,total,'NOTAS C-N3',f.scenario)
    y=34;y=section(c,16,y,178,'NOTAS DIGITALES','página exclusiva · prioridad digital')
    for i,e in enumerate(notes):
        lines=wraptext(e.text,170,7.1)
        h=9+len(lines)*4.1
        cartouche(c,16,y,178,h,'white')
        txt(c,19,y+5.2,e.text.split(':')[0].upper(),8,FHEAD,'title')
        line(c,19,y+7,190,y+7,'light',.4)
        for j,s in enumerate(lines):txt(c,19,y+11+j*4.1,s,7.1)
        registry.append(e.id);y+=h+3
    if y<273:
        yy=section(c,16,y,178,'ESPACIO PARA ESCRITURA')
        ruled(c,16,yy,178,int((272-yy)/7),7)

def note_pages(f):
    pages=[];part=[];y=43
    for e in f.notes:
        h=9+len(wraptext(e.text,170,7.1))*4.1+3
        if part and y+h>272:pages.append(part);part=[];y=43
        part.append(e);y+=h
    if part:pages.append(part)
    return pages

def book_card_height(e):
    lines=wraptext(e.extra,80,6.65)
    return 13+len(lines)*3.65+3

def book_pages(f):
    pages=[];part=[];col=0;y=35
    # Cards that do not fit in current column migrate entire to next one.
    for e in f.book:
        height=book_card_height(e)
        if height>232:raise ValueError('fixture contains over-column book card; deliberate design boundary')
        if y+height>272:
            col+=1;y=35
            if col==2:pages.append(part);part=[];col=0
        part.append((col,y,e,height));y+=height+3
    if part:pages.append(part)
    return pages

def draw_book(c,f,items,registry,pn,total):
    topframe(c,f.name,pn,total,'LIBRO DE CONJUROS OPCIONAL',f.scenario)
    for col,y,e,h in items:
        x=16+col*91
        cartouche(c,x,y,87,h)
        rect(c,x+1,y+1,85,11,'fog',None)
        txt(c,x+3,y+5.3,clipstring(e.text,69,8.2,FHEAD),8.2,FHEAD,'title')
        txt(c,x+84,y+5.2,'N '+e.value,6.7,FHEAD,'blue','right')
        txt(c,x+3,y+9.9,e.origin.upper(),6.3,FHEAD,'soft')
        for i,line_txt in enumerate(wraptext(e.extra,80,6.65)):
            txt(c,x+3,y+16.3+i*3.65,line_txt,6.65)
        registry.append(e.id)

def final_page(c,f,pn,total):
    topframe(c,f.name,pn,total,'HOJA FINAL MANUSCRITA',f.scenario)
    section(c,16,34,178,'DIARIO DE AVENTURAS','libre para lápiz · sin datos digitales')
    for j in range(2):
        x=16+j*91
        ruled(c,x,44,87,16,7)
    section(c,16,161,178,'MAPAS Y ESQUEMAS')
    gx,gy=16,170;gw,gh=178,102
    rect(c,gx,gy,gw,gh,None,'light',.35)
    for x in range(math.ceil(gw/5)+1):
        xx=gx+x*5
        if xx<=gx+gw:line(c,xx,gy,xx,gy+gh,'light',.2)
    for j in range(math.ceil(gh/5)+1):
        yy=gy+j*5
        if yy<=gy+gh:line(c,gx,yy,gx+gw,yy,'light',.2)


def render_c2(c,f,tiles,registry,pn,total,pageidx,layout='dos_columnas',first_page_no=4,comparison=False,module_pages=None):
    topframe(c,f.name,pn,total,'EXTENSIÓN C2 · '+layout.upper(),f.scenario)
    txt(c,16,34,('COMPARACIÓN AISLADA · NO USAR REFERENCIAS DE PÁGINAS' if comparison else 'Continuaciones por módulo · composición '+layout),6.7,FVAL,'soft')
    # References from origin to current physical page and back, calculated after order is fixed.
    for tile in tiles:
        if comparison: cue='ENSAYO '+layout
        else:
            related=module_pages.get(tile.kind,[]) if module_pages else []
            next_pages=[q for q in related if q>pn]
            cue='← '+ORIGIN[tile.kind].replace('P','BASE P.')
            if next_pages:cue+=' · SIG. P.'+str(next_pages[0])
        draw_tile(c,tile,registry,cue)
    # Sparse C2 pages retain usable pencil space instead of a large dead white region.
    if not comparison and tiles and sum(len(t.entries) for t in tiles)<=20 and len(tiles)<=2:
        end=max(t.y+t.h for t in tiles)+8
        if end<212:
            section(c,16,end,178,'ANOTACIONES MANUSCRITAS','complemento libre · sin contenido digital')
            yy=end+9
            for j in range(2):ruled(c,16+j*91,yy,87,max(0,int((271-yy)/7)),7)


def draw_nav(c,pages_by_module,base_page,module_keys,at_y=276):
    # Show first actual continuation page per relevant module; bounded in one footer line.
    cues=[]
    for k in module_keys:
        target=pages_by_module.get(k)
        if target is not None:cues.append(MODULE_NAME.get(k,k).title()+ ' → PÁG. '+str(target))
    if cues:
        rect(c,16,at_y-4,178,4.3,'ivory',None)
        txt(c,18,at_y-1,' · '.join(cues)[:155],5.7,FHEAD,'blue')


def compute_plan(f,layout='mixto'):
    # Automatic V8 C2 layout selection: minimize page count first, then maximize area utilization.
    if layout=='auto':
        candidate={mode:compute_plan(f,mode) for mode in ('vertical','dos_columnas','mixto')}
        best=min(candidate,key=lambda k:(candidate[k]['c2_metric']['pages'],-candidate[k]['c2_metric']['geometric_occupancy']))
        candidate[best]['selected_mode']=best
        candidate[best]['candidate_metrics']={k:v['c2_metric'] for k,v in candidate.items()}
        return candidate[best]
    # base reserved capacity and scenario allocations (match renderers)
    spill=collections.defaultdict(list)
    allocated={}
    if f.variant=='A':
        yy=72
        for i,a in enumerate(f.attrs):
            n=len(f.skillmap[a.text]);cap=274-yy-10.6*(len(f.attrs)-i-1)
            if cap<10.6:
                spill['skill'].append(a);spill['skill'].extend(f.skillmap[a.text]);continue
            take=min(n,max(0,int((cap-10.6)/5)))
            spill['skill'].extend(f.skillmap[a.text][take:])
            yy+=10.6+take*5
    else:
        # P1B layout: 9 attributes + 9 saving throws then 5-mm skills
        yy=72; yy+=8.5
        for a in f.attrs:
            if yy+9.5>272:spill['skill'].append(a)
            else:yy+=9.4
        yy+=2+8.5
        for a in f.attrs:
            if yy+4.6>272:break
            yy+=4.6
        yy+=2+8.5
        for e in [e for a in f.attrs for e in f.skillmap[a.text]]:
            if yy+5>273:spill['skill'].append(e)
            else:yy+=5
    spill['attack'].extend(f.attacks[5:])
    spill['equipment'].extend(f.equipment[14:])
    spill['coin'].extend(f.coins[8:])
    spill['special'].extend(f.special[8:])
    # Base P1(4) P2(18) P3(4); all remaining mechanical traits spill
    spill['trait'].extend(f.traits[26:])
    spill['story'].extend(f.story[10:])
    # Ammo registry uses exact two-row P1 cap; all remaining entries continue in C2
    spill['ammo'].extend(f.ammo[2:])
    # assume 4 traits P1, 18 P2, 4 P3
    if len(f.traits)>26:spill['trait'].extend(f.traits[26:])
    c2spills={k:v for k,v in spill.items() if k in H and v}
    c2pages,metrics=pack_c2(c2spills,layout)
    spells=plan_spell_pages(f.spells)
    notes=note_pages(f)
    books=book_pages(f)
    page_defs=[('base1',None),('base2',None),('base3',None)]+[('c2',v) for v in c2pages]+[('spells',v) for v in spells]+[('notes',v) for v in notes]+[('book',v) for v in books]+[('final',None)]
    per_module={}
    for i,(t,items) in enumerate(page_defs,1):
        if t=='c2':
            for tile in items:per_module.setdefault(tile.kind,i)
    return {'pages':page_defs,'c2_metric':metrics,'links':per_module,'spills':c2spills,'selected_mode':layout,'candidate_metrics':{layout:metrics}}

def render_doc(f,path,mode='mixto'):
    plan=compute_plan(f,mode);registry=[];c=canvas.Canvas(str(path),pagesize=A4,pageCompression=1)
    c.setTitle('Prototipo independiente V8 - '+f.name+' - '+f.variant)
    total=len(plan['pages'])
    module_pages=collections.defaultdict(list)
    for pi,(pk,items) in enumerate(plan['pages'],1):
        if pk=='c2':
            for tile in items:
                if pi not in module_pages[tile.kind]:module_pages[tile.kind].append(pi)
    for idx,(kind,payload) in enumerate(plan['pages'],1):
        if kind=='base1':
            topframe(c,f.name,idx,total,'BASE 1 / ATRIBUTOS '+f.variant,f.scenario)
            scratch=collections.defaultdict(list);base1(c,f,registry,scratch,plan['links'],f.variant)
            draw_nav(c,plan['links'],1,['skill','attack','ammo'])
        elif kind=='base2':
            topframe(c,f.name,idx,total,'BASE 2 / EQUIPO Y TESORO',f.scenario)
            scratch=collections.defaultdict(list);base2(c,f,registry,scratch)
            draw_nav(c,plan['links'],2,['equipment','coin','special'])
        elif kind=='base3':
            topframe(c,f.name,idx,total,'BASE 3 / HISTORIA',f.scenario)
            scratch=collections.defaultdict(list);base3(c,f,registry,scratch,f.traits[22:26])
            draw_nav(c,plan['links'],3,['story','trait'])
        elif kind=='c2':render_c2(c,f,payload,registry,idx,total,idx,plan['selected_mode'],module_pages=module_pages)
        elif kind=='spells':spellpage(c,f,payload,registry,idx,total)
        elif kind=='notes':draw_notes(c,f,payload,registry,idx,total)
        elif kind=='book':draw_book(c,f,payload,registry,idx,total)
        else:final_page(c,f,idx,total)
        c.showPage()
    c.save()
    observed=collections.Counter(registry)
    expected=set(f.full_ids)
    missing=sorted(expected-set(observed));dupe=sorted([k for k,v in observed.items() if v!=1]);unexpected=sorted(set(observed)-expected)
    return {'scenario':f.scenario,'variant':f.variant,'file':str(path),'pages':total,'c2':plan['c2_metric'],
            'counts':{'expected_ids':len(expected),'drawn_unique_ids':len(observed),'missing_ids':len(missing),'duplicate_ids':len(dupe),'unexpected_ids':len(unexpected)},
            'missing_sample':missing[:20],'dupe_sample':dupe[:20],'unexpected_sample':unexpected[:20],
            'links':plan['links'],'selected_mode':plan['selected_mode'],'candidate_metrics':plan['candidate_metrics'],'all_ids_match':len(missing)==len(dupe)==len(unexpected)==0}

def comparator_pdf(f,path):
    # same full C2 spill for each separate layout; compare actual A4 occupation and pages
    scenarios={key:compute_plan(f,key) for key in ['vertical','dos_columnas','mixto']}
    count=sum(v['c2_metric']['pages'] for v in scenarios.values())
    c=canvas.Canvas(str(path),pagesize=A4);c.setTitle('V8 Comparación C2 - tres composiciones')
    pn=0;metrics=[]
    for key,plan in scenarios.items():
        c2pgs=[items for t,items in plan['pages'] if t=='c2']
        for items in c2pgs:
            pn+=1;dummy=[]
            render_c2(c,f,items,dummy,pn,count,pn,key,comparison=True)
            c.showPage()
        metrics.append(plan['c2_metric'])
    c.save()
    return metrics

if __name__=='__main__':
    scenarios=[('v8_ordinario_6mas2_variante_A.pdf',mk_fixture(2,False,'A'),'auto'),
               ('v8_ordinario_6mas3_variante_A.pdf',mk_fixture(3,False,'A'),'auto'),
               ('v8_ordinario_6mas2_variante_B.pdf',mk_fixture(2,False,'B'),'auto'),
               ('v8_ordinario_6mas3_variante_B.pdf',mk_fixture(3,False,'B'),'auto'),
               ('v8_extremo_variante_A.pdf',mk_fixture(3,True,'A'),'auto'),
               ('v8_extremo_variante_B.pdf',mk_fixture(3,True,'B'),'auto')]
    # New/near-empty PC: no spells, notes or optional Spellbook, but all three bases and final blank.
    empty=mk_fixture(0,False,'A')
    empty.scenario='CASI VACÍO · PRUEBA FICTICIA'
    for name in ['attacks','traits','ammo','equipment','coins','special','story','spells','notes','book']:
        setattr(empty,name,[])
    scenarios.append(('v8_personaje_casi_vacio.pdf',empty,'auto'))
    results=[]
    for name,f,mode in scenarios:
        out=render_doc(f,DIR/name,mode);results.append(out)
        print(name,'pages',out['pages'],'IDs',out['counts'],'C2',out['c2'])
    met=comparator_pdf(scenarios[4][1],DIR/'v8_comparador_C2_extremo.pdf')
    results.append({'comparison':met})
    with open(DIR/'resultados_v8.json','w',encoding='utf8') as fp:json.dump(results,fp,ensure_ascii=False,indent=2)
