#!/usr/bin/env python3
"""Focused checks for owner's V11 corrections; synthetic fixtures, not App QA."""
import fitz,json,math
from pathlib import Path
import v11_generador as g
R=Path(__file__).resolve().parent
results=json.loads((R/'resultados_v11.json').read_text())
checks=[]
def check(ok,detail):checks.append({'ok':bool(ok),'test':detail})
def fixture(item):
    if 'extremo' in item['file']:return g.mk_fixture(3,True,item['variant'])
    if 'casi_vacio' in item['file']:
        f=g.mk_fixture(0,False,'A')
        for k in ('attacks','traits','ammo','equipment','coins','special','story','spells','notes','book'):setattr(f,k,[])
        return f
    return g.mk_fixture(3 if '6mas3' in item['file'] else 2,False,item['variant'])
for item in results:
    if 'comparador' in item['file']:continue
    f=fixture(item)
    alloc,plan,nav,mode,comp,metrics=g.build_plan(f)
    pdf=fitz.open(R/'pdfs'/item['file'])
    raw=[p.get_text() for p in pdf]
    check(len(pdf)==len(plan),item['file']+': model to physical pages')
    # No unexplained one-line gap between digital history paragraphs.
    bycol={0:[],1:[]}
    for entry,col,first,num in alloc['p3story']:
        bycol[col].append((first,num,entry.id))
    for col,entries in bycol.items():
        for a,b in zip(entries,entries[1:]):
            check(b[0]==a[0]+a[1],item['file']+f': history paragraphs directly adjacent, col {col} {a[2]}->{b[2]}')
    check('RASGOS PENDIENTES' not in raw[2],item['file']+': P3 exclusively narrative')
    # Final squared-paper grid: equal intervals and complete last cell.
    top=34.;step=6.7;count=17;gy=top+count*step+3.5
    h=259.-gy;w=187.9
    check(abs((h/round(h/5.5))*round(h/5.5)-h)<1e-8,item['file']+': final complete grid rows')
    check(abs((w/round(w/5.5))*round(w/5.5)-w)<1e-8,item['file']+': final complete grid columns')
    check(raw[-1].count('NOTAS')==1,item['file']+': final only Notes heading')
    # Spell level presence and every blank spell entry carries a real checkbox at its physical location.
    for pn,(kind,part) in enumerate(plan,1):
        if kind=='spells':
            rectkeys=set()
            for d in pdf[pn-1].get_drawings():
                for shape in d['items']:
                    if shape[0]=='re':
                        r=shape[1]
                        if 7.5<r.width<9.6 and 7.5<r.height<9.6:
                            rectkeys.add((round(r.x0,1),round(r.y0,1)))
            for typ,col,y,obj in part:
                if typ=='manual':
                    xx=(14+col*64.35+.9)*g.MM
                    yy=(y+1.3)*g.MM
                    check((round(xx,1),round(yy,1)) in rectkeys,item['file']+f': markable manual spell row p{pn} col{col} y{y}')
            for col in range(3):
                if not any(q[1]==col for q in part):
                    # Empty column should be identified as handwritten Notes, not unlabelled ruled paper.
                    check('NOTAS' in raw[pn-1],item['file']+f': missing spell column filled as Notes p{pn}')
    # Every C2 column with >=13mm available reserve shows handwritten Notes, never unexplained loose rules.
    for pn,(kind,part) in enumerate(plan,1):
        if kind!='c2':continue
        needed=0
        for x in (14,109.7):
            bottoms=[t.y+t.h for t in part if abs(t.x-x)<.1 or t.w>100]
            rem=258.4-(max([39]+bottoms)+2)
            if rem>=13:needed+=1
        check(raw[pn-1].count('NOTAS')>=needed,item['file']+f': C2 spare areas named NOTES p{pn}')
        check('\x00' not in raw[pn-1],item['file']+f': C2 navigation avoids missing glyphs p{pn}')
    # A's custom attributes are physically followed by their own skill names without redundant suffix.
    if 'extremo' in item['file'] and f.variant=='A':
        c2text=' '.join(raw[pn-1] for pn,(kind,_) in enumerate(plan,1) if kind=='c2')
        check('Sello (COR)' not in c2text and 'Lectura (HON)' not in c2text,item['file']+': no suffix for adjacent custom-stat skills')
        check('CORDURA' in c2text and 'HONOR' in c2text,item['file']+': custom attribute plus related skills in C2')
    if f.variant=='B' and f.spells:
        check('(FUE)' in raw[0],item['file']+': B independent skill retains source statistic suffix')
    pdf.close()
summary={'passed':sum(x['ok'] for x in checks),'total':len(checks),'failed':[x for x in checks if not x['ok']]}
(R/'QA_V11_CORRECCIONES.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print('V11 CORRECCIONES',summary['passed'],'/',summary['total'])
for x in summary['failed'][:20]:print('FAIL:',x['test'])
if summary['failed']:raise SystemExit(1)
