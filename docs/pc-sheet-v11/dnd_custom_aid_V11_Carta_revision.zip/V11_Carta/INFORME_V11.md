# V11 — Revisión visual de hoja de personaje (prototipo independiente)

**Estado:** PIN VISUAL ACTIVO / NO APROBADO. Carta de 612 × 792 pt (215,9 × 279,4 mm). No procede del renderer de Android ni Desktop y no modifica el repositorio.

## Cambios respecto de V10

1. **P1:** etiqueta «SALVACIÓN» vinculada visualmente a la casilla de tirada; no se alteraron las cartelas y óvalos aprobados.
2. **Habilidades:** cuando el nombre aparece inmediatamente debajo de su atributo, se omite `(COR)`, `(HON)` u otro sufijo. En listas independientes se conserva siempre `(XXX)`, con tres mayúsculas.
3. **Historia:** texto impreso sobre los renglones existentes, sin la línea vacía artificial entre párrafos; narrativa íntegra o continuada cuando corresponda.
4. **Conjuros:** niveles 0–9 siempre presentes en la lista rápida cuando hay conjuros reales. En casos ordinarios, las tres columnas comparten proporcionalmente el área física. Los conjuros extremos siguen en dos páginas mediante continuación por nivel; en ningún caso se inventan niveles 10–12. Cada renglón manuscrito vacío incluye casilla.
5. **C2:** espacios sobrantes utilizables como pequeñas cuadrículas **NOTAS** rotuladas. Son escritura a mano, no páginas de Notas digitales C-N3. Permanecen dos columnas para Equipo, ancho completo para Equipo Especial y navegación bidireccional física.
6. **Página final:** cuadrícula calculada con celdas enteras de paso uniforme. Ninguna fila o columna acaba parcialmente recortada; el único encabezado es «Notas».
7. **Navegación:** se evitan flechas sin soporte tipográfico en la fuente sustituta; referencias físicas legibles.

## Resultados medidos

| Caso | V10, páginas | V11, páginas | Identificadores únicos V11 |
| --- | ---: | ---: | ---: |
| Casi vacío | 4 | 4 | 24/24 |
| 6+2, A / B | 7 / 7 | 7 / 7 | 93/93 por variante |
| 6+3, A / B | 7 / 7 | 7 / 7 | 97/97 por variante |
| Extremo A | 11 | **11** | 386/386 |
| Extremo B | 11 | **10** | 386/386 |

La variante extrema A necesita tres páginas C2, B necesita dos. La comparación independiente C2 contiene seis páginas de diseño (dos columnas y mixto). Las diferencias dependen del fixture simulado y **no equivalen a una mejora del renderer real**.

**QA:** `QA_V11.json` — 672/672 controles generales. `QA_V11_CORRECCIONES.json` — 432/432 controles de V11 (casillas manuales por coordenada PDF, continuidad de párrafos, cuadrículas, ocupación C2, sufijos de habilidades, etc.). **Total: 1.104/1.104 controles automatizados superados.** También se regeneraron ocho PDFs en una carpeta independiente con las mismas páginas y texto extraído.

## Limitaciones abiertas

- No incorpora Barlow Condensed auténtica ni Para Hoja de PJ Symbols v8: las etiquetas y las casillas usan sustitutos tipográficos/vectoriales, **no afirmar cumplimiento de fuentes/iconos**.
- El logo es una marca textual provisional, no el asset oficial aprobado.
- Las tres casillas de ejemplo en los encabezados de espacios mágicos **no son una progresión de slots validada**. Fuentes, CD, estados y equipamiento son ficticios. Verificar con el modelo de datos de la App antes de producción.
- Faltan pruebas con datos reales de la App, trazabilidad de propiedades/semánticas, impresión física y escritura con lápiz al 100 %.
- No está resuelta la división de fichas del Libro de Conjuros cuya descripción supere una columna completa: el prototipo detiene ese caso, no elimina contenido.
- Los renglones de habilidades A continúan en torno a 4,4 mm; ergonomía manuscrita no verificada físicamente.
- Esta V11 no implica aceptación estética, implantación en Android/Desktop, aprobación de variantes, ni autorización para modificar GitHub. PIN VISUAL ACTIVO.

## Ejecución independiente

Entorno: Python 3.13 con `reportlab`, `pymupdf` y fuentes de sistema Noto Sans / EB Garamond instaladas. Desde la carpeta del paquete:

```bash
python v11_generador.py
python qa_v11.py
python qa_v11_correcciones.py
```

El generador escribe los ocho PDFs dentro de `pdfs/`. Los PDF finales incorporan las fuentes utilizadas, pero **no se redistribuyen archivos de fuentes**. Su aspecto solo se reproduce exactamente si están disponibles las tipografías de prueba del entorno.
