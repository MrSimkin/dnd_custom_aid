#!/usr/bin/env python3
"""Prototipo independiente V10, papel Carta. No es el renderer de dnd_custom_aid.
Fixtures reconstruidos de V8; iconografía y estados reales de App pendientes.
"""
import os, math, json, re, collections, itertools
from pathlib import Path
from dataclasses import dataclass
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics
from reportlab.lib.colors import HexColor
from reportlab.lib.utils import simpleSplit
from prototipo_v8_base import mk_fixture, Entry, CLASSIC

HERE=Path(__file__).resolve().parent
OUT=HERE/'pdfs'; OUT.mkdir(exist_ok=True)
MM=72/25.4
PW,PH=letter
W,H=PW/MM,PH/MM
FONTDIR='/usr/share/fonts/truetype'
for key,path in [('Label',FONTDIR+'/noto/NotoSansDisplay-CondensedBold.ttf'),('Body',FONTDIR+'/noto/NotoSans-Regular.ttf'),('BodyBold',FONTDIR+'/noto/NotoSans-Bold.ttf'),('Hero',FONTDIR+'/ebgaramond/EBGaramond12-Bold.ttf')]:
    pdfmetrics.registerFont(TTFont(key,path))
COLOR={'ink':'#24394b','navy':'#264b68','deep':'#1d384f','line':'#94b0c1','pale':'#e7f2f7','alt':'#f0f7fa','white':'#ffffff','silver':'#bfd3de','quiet':'#657d90','edge':'#527c96'}
def col(n):return HexColor(COLOR.get(n,n))
def M(x):return x*MM
# All layout measurements are in physical millimeters on US Letter.
def line(c,x,y,X,Y,ink='line',weight=.32):
    c.setStrokeColor(col(ink));c.setLineWidth(weight);c.line(M(x),PH-M(y),M(X),PH-M(Y))
def rect(c,x,y,w,h,fill=None,stroke='line',sw=.55):
    c.setStrokeColor(col(stroke or 'white'));c.setFillColor(col(fill or 'white'));c.setLineWidth(sw)
    c.rect(M(x),PH-M(y+h),M(w),M(h),stroke=1 if stroke else 0,fill=1 if fill else 0)
def poly(c,points,fill='white',stroke='navy',sw=.55):
    p=c.beginPath();p.moveTo(M(points[0][0]),PH-M(points[0][1]))
    for x,y in points[1:]:p.lineTo(M(x),PH-M(y))
    p.close();c.setFillColor(col(fill));c.setStrokeColor(col(stroke));c.setLineWidth(sw);c.drawPath(p,stroke=1,fill=1)
def text(c,x,y,s,size=8,font='Body',ink='ink',align='left'):
    c.setFillColor(col(ink));c.setFont(font,size)
    fn={'left':c.drawString,'right':c.drawRightString,'center':c.drawCentredString}[align]
    fn(M(x),PH-M(y),str(s))
def text_width(s,font='Body',size=8):return pdfmetrics.stringWidth(str(s),font,size)/MM
def fit(s,maxw,font='Body',start=8,minimum=5.75):
    for sz in [start-i*.15 for i in range(int((start-minimum)/.15)+1)]:
        if text_width(s,font,sz)<maxw:return sz
    return minimum

def wrap(s,width,size=7,font='Body'):
    return [l for part in str(s).split('\n') for l in (simpleSplit(part,font,size,M(width)) if part else [''])]

def star(c,x,y,r=1.3):
    poly(c,[(x,y-r),(x+r*.57,y),(x,y+r),(x-r*.57,y)],'white','edge',.48)
def cart(c,x,y,w,h,fill=None):
    # exterior cartela de esquinas recortadas C2c, remates de fantasía contenidos
    k=min(2.2,h*.23,w*.11)
    poly(c,[(x+k,y),(x+w-k,y),(x+w,y+k),(x+w,y+h-k),(x+w-k,y+h),(x+k,y+h),(x,y+h-k),(x,y+k)],fill or 'white','navy',.65)
    if w>20:
        line(c,x+3.2,y+1.2,x+w-3.2,y+1.2,'silver',.35)

def ribbon(c,x,y,w,title,subtitle=''):
    cart(c,x,y,w,8.1,'pale')
    star(c,x+3,y+4.1,1.1); star(c,x+w-3,y+4.1,1.1)
    text(c,x+6,y+5.7,title.upper(),9.1,'Label','deep')
    if subtitle and text_width(subtitle,'Body',6.2)<w*.44:
        text(c,x+w-6,y+5.25,subtitle,6.2,'Body','quiet','right')
    return y+8.8

def ruled(c,x,y,w,n,h=5.5,start=0):
    for i in range(max(0,n)):
        rect(c,x,y+i*h,w,h,'pale' if (i+start)%2==0 else 'alt',None)
        line(c,x,y+(i+1)*h-.35,x+w,y+(i+1)*h-.35,'line',.32)
    return y+n*h

def box(c,x,y,size=3.15,off=False):
    rect(c,x,y,size,size,'silver' if off else 'white','edge',.48)
    if off:
        line(c,x+.4,y+.5,x+size-.4,y+size-.4,'quiet',.45)
        line(c,x+.4,y+size-.4,x+size-.4,y+.5,'quiet',.45)

def crest(c):
    # Logo textual provisional: no simula ser recurso D&D original aprobado.
    text(c,15,19.1,'DUNGEONS',12.3,'Hero','deep')
    text(c,15,23.1,'& DRAGONS',11.0,'Hero','navy')
    line(c,15,24.1,46,24.1,'edge',.65)
    # pequeño escudo heráldico vectorial, ornamental, no logotipo oficial
    poly(c,[(48.9,15.2),(53.8,16.7),(53.5,22.6),(51.3,25.2),(49.1,22.6)],'white','edge',.58)
    line(c,49.7,17.1,52.8,22.5,'navy',.6)
    line(c,52.8,17.1,49.7,22.5,'navy',.6)
    star(c,51.25,20.0,1.0)

def frame(c,name,page,total,kind,scenario):
    # Doble marco C2 exterior, adaptado a tamaño Carta
    rect(c,9.3,8.8,W-18.6,H-17.6,None,'navy',.95)
    rect(c,10.8,10.2,W-21.6,H-20.4,None,'silver',.38)
    for x in (10.6,W-10.6):
        for y in (10.0,H-10.0):star(c,x,y,1.25)
    # remates curvos interiores evocan una hoja de crónica fantástica
    for x,side in ((13.4,1),(W-13.4,-1)):
        for y,direction in ((13.5,1),(H-13.5,-1)):
            line(c,x,y,x+side*5,y,'silver',.55)
            line(c,x,y,x,y+direction*5,'silver',.55)
            star(c,x+side*5.6,y+direction*.1,.85)
    crest(c)
    line(c,54,14.7,54,27.0,'silver',.4)
    # siempre mismo renglón de membrete para nombre del PJ, sin segunda fila
    text(c,57,20.0,name,fit(name,96,'Hero',13.4,9.4),'Hero','deep')
    text(c,W-15,16.3,kind,7.3,'Label','navy','right')
    if kind!='NOTAS':text(c,W-15,23.8,scenario,5.9,'Label','quiet','right')
    line(c,14,29.0,W-14,29.0,'edge',.55)
    line(c,14,H-15.9,W-14,H-15.9,'edge',.55)
    if kind!='NOTAS':text(c,15,H-11.6,'MAQUETA V11 · DATOS FICTICIOS · INDEPENDIENTE DE LA APP',6.1,'Body','quiet')
    text(c,W-15,H-11.5,f'{page:02d} / {total:02d}',7.4,'Label','navy','right')

def to_display(origin):return {'CL':'Clase','RA':'Raza','DO':'Dote'}.get(origin,origin)

MODULE={'skill':'HABILIDADES','attack':'ATAQUES','trait':'RASGOS','equipment':'EQUIPO','coin':'TESORO','special':'EQUIPO ESPECIAL','story':'HISTORIA','ammo':'MUNICIONES'}
ORIGINS={'skill':'1','attack':'1','trait':'1–3','equipment':'2','coin':'2','special':'2','story':'3','ammo':'1'}
RHEIGHT={'skill':5.1,'attack':5.2,'trait':5.3,'equipment':5.6,'coin':6.5,'special':10.0,'story':13.0,'ammo':12.0}

def textrow(c,x,y,w,value,h,kind,idx,registry=None):
    ruled(c,x,y,w,1,h,idx)
    if kind=='skill':
        box(c,x+1.3,y+(h-3)/2,3)
        sz=fit(value.text,w-22,'Body',7.2,6.1)
        text(c,x+5.4,y+h*.69,value.text,sz)
        text(c,x+w-2,y+h*.69,value.value,7.5,'BodyBold','navy','right')
    elif kind=='trait':
        sz=fit(value.text,w-5,'Body',7.1,6.1)
        text(c,x+1.8,y+h*.71,value.text,sz)
    elif kind=='attack':
        # bonificador más estrecho, tres columnas constantes
        a=.61*w;b=.73*w
        line(c,x+a,y,x+a,y+h,'line',.35);line(c,x+b,y,x+b,y+h,'line',.35)
        text(c,x+1.6,y+h*.69,value.text,fit(value.text,a-3,'Body',7.4,6.1))
        text(c,x+(a+b)/2,y+h*.69,value.value,7.1,'BodyBold','navy','center')
        text(c,x+w-1.4,y+h*.69,value.extra,fit(value.extra,w*(1-b/w)-2,'Body',6.7,5.8),'Body','ink','right')
    elif kind=='equipment':
        a=w*.75;line(c,x+a,y,x+a,y+h,'line',.35)
        text(c,x+1.6,y+h*.72,value.text,fit(value.text,a-3,'Body',7.2,6.0))
        text(c,x+w-2,y+h*.72,value.value,7.2,'BodyBold','navy','right')
    elif kind=='coin':
        a=w*.72;line(c,x+a,y,x+a,y+h,'line',.35)
        text(c,x+1.5,y+h*.72,value.text,fit(value.text,a-2,'Body',7.1,5.9))
        text(c,x+w-2,y+h*.72,value.value,7.2,'BodyBold','navy','right')
    elif kind=='special':
        # misma estructura/frecuencia de renglones con datos o vacíos
        ax=.19*w;bx=.45*w;cx=.92*w
        for z in (ax,bx,cx):line(c,x+z,y,x+z,y+h,'line',.34)
        text(c,x+1.1,y+4.0,value.origin or '_________',fit(value.origin or '_________',ax-2.1,'Body',6.8,5.6),'Body','navy')
        text(c,x+ax+1.3,y+4.0,value.text,fit(value.text,(bx-ax)-2.1,'Body',6.8,5.5))
        for j,s in enumerate(wrap(value.extra,(cx-bx)-2.2,6.2)[:2]):
            text(c,x+bx+1.3,y+3.7+j*3.65,s,6.2)
        box(c,x+cx+(w-cx)/2-1.6,y+(h-3.2)/2,3.2)
    elif kind=='ammo':
        text(c,x+1.6,y+4.1,value.text,fit(value.text,w-(88 if int(value.value or '0')>20 else 57),'Body',6.9,5.7))
        n=int(value.value or '0') if value.value else 0
        if n>20:
            # ajuste del propietario en la revisión V8: 20 casillas siempre,
            # más contador cuando X>20. Aún NO equivale a estado de App.
            text(c,x+w-55,y+4.1,'____ / '+str(n),7.2,'BodyBold','navy','right')
        # veinte casillas en dos subfilas, agrupadas de cinco
        bx=x+w-53
        for i in range(20):
            xx=bx+(i%10)*4.85 + (1.0 if i%10>=5 else 0)
            yy=y+(.55 if i<10 else 6)
            box(c,xx,yy,2.8,off=(i>=n and bool(value.value) and n<=20))
    elif kind=='story':
        lines=wrap(value.text,w-4,6.7)
        for i,s in enumerate(lines):text(c,x+1.8,y+4.3+i*3.75,s,6.7)
    if registry is not None:registry.append(value.id)

def attr_head(c,x,y,w,a,i,registry,small=False):
    ht=6.8 if small else 7.4
    ruled(c,x,y,w,1,ht,i)
    text(c,x+1.3,y+3.3,a.text.upper(),fit(a.text,31,'Label',8.1,6.8),'Label','deep')
    cart(c,x+1.2,y+3.8,17,3.0)
    text(c,x+9.7,y+6.65,a.value,8.6,'Label','navy','center')
    # oval FULLY within header, does not cut carton nor hit next row
    c.setStrokeColor(col('navy'));c.setFillColor(col('white'));c.setLineWidth(.53)
    c.ellipse(M(x+19.2),PH-M(y+6.85),M(x+29.5),PH-M(y+3.7),stroke=1,fill=1)
    text(c,x+24.4,y+6.05,a.extra,6.8,'Label','navy','center')
    text(c,x+33,y+5.75,'SALVACIÓN',6.25,'Label','deep')
    box(c,x+w-14.0,y+3.7,2.9)
    text(c,x+w-1.0,y+6.0,a.extra,6.65,'BodyBold','navy','right')
    registry.append(a.id)
    return ht

def statbox(c,x,y,w,h,label,val):
    cart(c,x,y,w,h)
    text(c,x+2,y+3.7,label,fit(label,w-4,'Label',6.65,5.2),'Label','quiet')
    text(c,x+w/2,y+h-2,val,10.7,'Label','deep','center')

def identity(c,f):
    # perfil compacto con más superficie para clase y nivel, y retrato cuadrado
    cart(c,14,33,28,27)
    # retrato ausente: silueta
    c.setFillColor(col('pale'));c.setStrokeColor(col('silver'))
    c.circle(M(28),PH-M(40.3),M(4.0),stroke=1,fill=1)
    c.ellipse(M(20.5),PH-M(56.6),M(35.5),PH-M(46.0),stroke=1,fill=1)
    text(c,28,59,'RETRATO',5.5,'Label','quiet','center')
    cart(c,45,33,100,12)
    text(c,47,37,'NOMBRE DEL PERSONAJE',5.6,'Label','quiet')
    text(c,47,42.5,f.name,fit(f.name,95,'Hero',12.7,9),'Hero','deep')
    cart(c,147.5,33,54.4,12)
    text(c,150,37,'CLASE / NIVEL',6.2,'Label','quiet')
    text(c,150,42.1,'Maga exploradora / 8',fit('Maga exploradora / 8',50,'Body',8.2,7.0))
    cart(c,45,47.0,52,13)
    text(c,47,51.0,'JUGADOR',5.9,'Label','quiet')
    text(c,47,56.5,'Personaje ficticio',7.2)
    cart(c,99,47.0,61.8,13)
    text(c,101,51,'RAZA',5.9,'Label','quiet')
    text(c,101,56.5,'Humana',7.4)
    cart(c,162.8,47.0,39.1,13)
    text(c,164.6,51,'ALINEAMIENTO',5.7,'Label','quiet')
    text(c,164.6,56.5,'Neutral',7.2)


def allocations(f):
    """One source of truth for base capacity and spills; painter only consumes this plan."""
    result={'p1attrs':[],'p1skills':[],'p1attacks':f.attacks[:5], 'p1traits':f.traits[:14], 'p1ammo':f.ammo[:2],
            'p2equip':f.equipment[:26],'p2coins':f.coins[:10], 'p2traits':f.traits[14:26], 'p2special':f.special[:8],
            'p3story':[],'p3traits':f.traits[26:30]}
    spills=collections.defaultdict(list)
    # P1 A attrs 7.4mm, skills nominal 4.65 mm; P1 B attr+save per row, then skills
    if f.variant=='A':
        y=73.8
        for ix,a in enumerate(f.attrs):
            skills=f.skillmap[a.text]
            reserve=(len(f.attrs)-ix-1)*7.4
            # keep all original six; prioritize others but enforce space for their header
            avail=261.5-y-reserve-7.4
            n=max(0,min(len(skills),int((avail+0.001)/4.45)))
            result['p1attrs'].append((a,skills[:n]));spills['skill']+=skills[n:]
            y+=7.4+n*4.65
    else:
        result['p1attrs']=[(a,[]) for a in f.attrs]
        y=72.6+len(f.attrs)*6.8+8.8
        skills=[e for a in f.attrs for e in f.skillmap[a.text]]
        take=max(0,min(len(skills),int((260-y)/4.5)))
        result['p1skills']=skills[:take]
        spills['skill']+=skills[take:]
    spills['attack']+=f.attacks[5:];spills['trait']+=f.traits[30:]
    spills['ammo']+=f.ammo[2:]
    spills['equipment']+=f.equipment[26:]
    spills['coin']+=f.coins[10:]
    spills['special']+=f.special[8:]
    # narrative heights follow actual wrapped content (not arbitrary truncated fixed number)
    y=135
    for e in f.story:
        ht=max(11.7,len(wrap(e.text,109,6.7))*3.75+2.8)
        if y+ht<=260.3:result['p3story'].append((e,ht));y+=ht
        else:spills['story'].append(e)
    result['spills']=spills
    return result

def p1(c,f,a,reg):
    identity(c,f)
    LX,LW,RX,RW=14,77.8,95.4,106.5
    y=ribbon(c,LX,63.8,LW,'ATRIBUTOS · '+f.variant)
    if f.variant=='A':
        for i,(at,skills) in enumerate(a['p1attrs']):
            y+=attr_head(c,LX,y,LW,at,i,reg)
            for j,e in enumerate(skills):
                textrow(c,LX,y,LW,e,4.65,'skill',j,reg);y+=4.65
    else:
        for i,(at,_) in enumerate(a['p1attrs']):y+=attr_head(c,LX,y,LW,at,i,reg,small=True)
        y=ribbon(c,LX,y+1.4,LW,'HABILIDADES','salvaciones en atributos')
        for i,e in enumerate(a['p1skills']):textrow(c,LX,y,LW,e,4.5,'skill',i,reg);y+=4.5
    if y<260.5:ruled(c,LX,y,LW,int((260.5-y)/4.45),4.65)
    y=ribbon(c,RX,63.8,RW,'COMBATE Y SUPERVIVENCIA')
    stats=[('CA','16'),('INICIATIVA','+3'),('VELOCIDAD','9 m'),('COMPETENCIA','+3'),('INSPIRACIÓN',''),('DADOS DE GOLPE','8d8')]
    gw=(RW-2)/3
    for i,(lbl,val) in enumerate(stats):statbox(c,RX+(i%3)*(gw+1),y+(i//3)*11.1,gw,10.5,lbl,val)
    y+=23.3
    for i,(lbl,val) in enumerate([('PV ACTUALES','46'),('PV MÁXIMOS','50')]):statbox(c,RX+i*(RW/2),y,RW/2-1.1,11.0,lbl,val)
    y+=12.1
    y=ribbon(c,RX,y,RW,'ATAQUES')
    ruled(c,RX,y,RW,1,4.4)
    text(c,RX+1.5,y+3.25,'ARMA / ATAQUE / CONJURO',6.2,'Label','navy')
    text(c,RX+RW*.67,y+3.25,'BON.',6.0,'Label','navy','center')
    text(c,RX+RW-1.5,y+3.25,'DAÑO / TIPO',6.0,'Label','navy','right')
    y+=4.4
    for i in range(5):
        if i<len(a['p1attacks']):textrow(c,RX,y,RW,a['p1attacks'][i],5.2,'attack',i,reg)
        else:ruled(c,RX,y,RW,1,5.2,i)
        y+=5.2
    y+=1
    y=ribbon(c,RX,y,RW,'RASGOS Y ATRIBUTOS','dos columnas')
    cw=(RW-2)/2
    for i in range(7):
        for j in range(2):
            idx=i+j*7;x=RX+j*(cw+2)
            if idx<len(a['p1traits']):textrow(c,x,y+i*5.1,cw,a['p1traits'][idx],5.1,'trait',i,reg)
            else:ruled(c,x,y+i*5.1,cw,1,5.1,i)
    y+=7*5.1+1.1
    y=ribbon(c,RX,y,RW,'LANZAMIENTO DE CONJUROS')
    sw=(RW-2)/3
    for i,(lbl,val) in enumerate([('APTITUD MÁGICA','INT'),('CD SALVACIÓN','15'),('ATAQUE MÁGICO','+7')]):statbox(c,RX+i*(sw+1),y,sw,9.2,lbl,val)
    y+=10.5
    for row in range(3):
        for j in range(3):
            lv=row*3+j+1;cx=RX+j*(sw+1);cy=y+row*6.7
            ruled(c,cx,cy,sw,1,6.7,row+j)
            text(c,cx+1.8,cy+4.6,f'N{lv}',7.0,'Label','navy')
            # vacías para escribir; NO supone una progresión de slots de la App
            for k in range(3):box(c,cx+12+k*6,cy+1.65,3.1)
    y+=20.7
    y=ribbon(c,RX,y,RW,'MUNICIONES')
    if a['p1ammo']:
        for i,e in enumerate(a['p1ammo']):textrow(c,RX,y+i*12,RW,e,12,'ammo',i,reg)
        y+=12*len(a['p1ammo'])
    else:
        # una fila lógica vacía, casillas sin bloquear
        pseudo=Entry('__manual__','Tipo: ___________________',value='')
        textrow(c,RX,y,RW,pseudo,12,'ammo',0,None);y+=12
    if y<260:ruled(c,RX,y,RW,int((260-y)/5.5),5.5)

def p2(c,f,a,reg):
    LX,LW,RX,RW=14,91.3,109.1,92.8
    y=ribbon(c,LX,34.0,LW,'EQUIPO','OBJETO / CANTIDAD')
    tw=(LW-2)/2
    for i in range(13):
        for j in range(2):
            idx=i+j*13;x=LX+j*(tw+2)
            if idx<len(a['p2equip']):textrow(c,x,y+i*5.7,tw,a['p2equip'][idx],5.7,'equipment',i,reg)
            else:ruled(c,x,y+i*5.7,tw,1,5.7,i)
    y+=13*5.7+3
    y=ribbon(c,LX,y,LW,'TESORO','denominación / cantidad')
    tw=(LW-2)/2
    for i in range(5):
        for j in range(2):
            idx=i+j*5;x=LX+j*(tw+2)
            if idx<len(a['p2coins']):textrow(c,x,y+i*7,tw,a['p2coins'][idx],7,'coin',i,reg)
            else:ruled(c,x,y+i*7,tw,1,7,i)
    # Ensure horizontal ruled lines in remaining left upper space
    ry=ribbon(c,RX,34,RW,'RASGOS Y ATRIBUTOS','mecánicos')
    twr=(RW-1.4)/2
    for i in range(12):
        for j in range(2):
            idx=i+j*12;x=RX+j*(twr+1.4)
            if idx<len(a['p2traits']):textrow(c,x,ry+i*5.4,twr,a['p2traits'][idx],5.4,'trait',i,reg)
            else:ruled(c,x,ry+i*5.4,twr,1,5.4,i)
    # right reserve additional renglones (not dead whitespace)
    tail=ry+12*5.4
    if tail<170:ruled(c,RX,tail,RW,int((170-tail)/5.6),5.6)
    sy=ribbon(c,14,167.8,187.9,'EQUIPO ESPECIAL','ACTIVO: marcar a lápiz')
    headh=5.3
    ruled(c,14,sy,187.9,1,headh)
    for xpos in (14+187.9*.19,14+187.9*.45,14+187.9*.92):line(c,xpos,sy,xpos,sy+headh,'line',.34)
    text(c,15.4,sy+3.8,'UBICACIÓN',6.8,'Label','navy')
    text(c,14+187.9*.19+1.6,sy+3.8,'NOMBRE',6.8,'Label','navy')
    text(c,14+187.9*.45+1.6,sy+3.8,'DESCRIPCIÓN',6.8,'Label','navy')
    text(c,14+187.9*.92+1.0,sy+3.8,'ACTIVO',5.5,'Label','navy')
    sy+=headh
    # All real/manual special rows follow IDENTICAL grid geometry
    default_locs=['Cabeza','Rostro','Cuello','Mano izquierda','Mano derecha','Pecho','Piernas','Libre']
    for i in range(8):
        if i<len(a['p2special']):val=a['p2special'][i];textrow(c,14,sy+i*9.5,187.9,val,9.5,'special',i,reg)
        else:textrow(c,14,sy+i*9.5,187.9,Entry('__manual__','',origin=default_locs[i],extra=''),9.5,'special',i,None)

def p3(c,f,a,reg):
    LX,LW,RX,RW=14,112.5,130,71.9
    y=ribbon(c,LX,34,LW,'TRASFONDO Y PERFIL NARRATIVO')
    fields=[('TRASFONDO','Cartógrafa de los umbrales'),('RELIGIÓN / FE','Culto del faro'),('RASGOS DE PERSONALIDAD','Observadora y paciente'),('IDEALES','La verdad precede a la gloria'),('VÍNCULOS','Juramento con el grupo'),('DEFECTOS','Desconfía de los acertijos fáciles')]
    for i,(label,val) in enumerate(fields):
        if not f.story:val=''
        h=14 if i==0 else 11.1
        ruled(c,LX,y,LW,1,h,i)
        text(c,LX+2,y+4.1,label,6.4,'Label','navy')
        text(c,LX+2,y+8.8,val,fit(val,LW-6,'Body',7.3,6.3))
        y+=h
    y=ribbon(c,LX,y+2.5,LW,'HISTORIA')
    for i,(e,h) in enumerate(a['p3story']):
        textrow(c,LX,y,LW,e,h,'story',i,reg);y+=h
    if y<261:ruled(c,LX,y,LW,int((261-y)/6),6)
    yy=ribbon(c,RX,34,RW,'RASGOS PENDIENTES')
    for i in range(5):
        if i<len(a['p3traits']):textrow(c,RX,yy,RW,a['p3traits'][i],5.5,'trait',i,reg)
        else:ruled(c,RX,yy,RW,1,5.5,i)
        yy+=5.5
    yy=ribbon(c,RX,yy+3,RW,'HISTORIA MANUSCRITA')
    ruled(c,RX,yy,RW,int((261-yy)/6.5),6.5)

def spillheight(kind,e,w):
    if kind=='story':return max(10.5,len(wrap(e.text,w-4,6.7))*3.75+3)
    if kind=='special':return max(10,len(wrap(e.extra,w*.43,6.2))*3.65+3)
    if kind=='skill' and e.id.startswith('AT'):return 7.4
    return RHEIGHT[kind]

@dataclass
class Tile:
    kind:str; entries:list; x:float=0; y:float=0; w:float=0; h:float=0; page:int=0

def make_tiles(spills,mode):
    out=[]
    for kind,items in spills.items():
        if not items:continue
        wide=mode=='mixto' and kind in ('attack','special','story')
        width=187.9 if wide else 92.2
        # target coherent chunks; long C2 pages should use available space
        chunk=[];height=8.8
        for e in items:
            hh=spillheight(kind,e,width)
            if chunk and height+hh>192:
                out.append(Tile(kind,chunk,w=width,h=height));chunk=[];height=8.8
            if hh>215:raise RuntimeError(f'fila demasiado grande en C2: {e.id}')
            chunk.append(e);height+=hh
        if chunk:out.append(Tile(kind,chunk,w=width,h=height))
    return out

def pack_spills(spills,mode):
    assert mode in ('dos_columnas','mixto')
    tiles=make_tiles(spills,mode)
    pages=[];active=[];ly=ry=37.5;num=0
    def end():
        nonlocal active,ly,ry,num
        if active:pages.append(active)
        active=[];ly=ry=37.5;num+=1
    for t in tiles:
        if t.w>100:
            y=max(ly,ry)
            if y+t.h>258.5:end();y=37.5
            t.x=14;t.y=y;t.w=187.9;ly=ry=y+t.h+2
        else:
            # pages filled left-to-right, prefer two columns
            if ly+t.h<=258.5:t.x,t.y=14,ly;ly+=t.h+2
            elif ry+t.h<=258.5:t.x,t.y=109.7,ry;ry+=t.h+2
            else:end();t.x,t.y=14,ly;ly+=t.h+2
        t.page=num;active.append(t)
    if active:pages.append(active)
    occupied=sum(t.h*t.w for t in tiles)/(len(pages)*187.9*221) if pages else 0
    return pages,{'mode':mode,'pages':len(pages),'items':sum(len(t.entries) for t in tiles),'tiles':len(tiles),'occupied_pct':round(occupied*100,1)}

def draw_c2(c,f,tiles,reg,pn,total,module_pages,mode,comparison=False):
    frame(c,f.name,pn,total,'CONTINUACIONES C2',f.scenario)
    text(c,14,35.3,'MÓDULOS COMPARTIDOS · '+mode.replace('_',' ').upper(),7.5,'Label','navy')
    for tile in tiles:
        yy=ribbon(c,tile.x,tile.y,tile.w,MODULE[tile.kind])
        if not comparison:
            related=module_pages.get(tile.kind,[])
            nav='VIENE P. '+ORIGINS[tile.kind]
            later=[p for p in related if p>pn]
            if later:nav+=' / SIG. '+str(later[0])
            text(c,tile.x+tile.w-2,tile.y+6.0,nav,6.1,'Label','navy','right')
        for i,e in enumerate(tile.entries):
            ht=spillheight(tile.kind,e,tile.w)
            if tile.kind=='skill' and e.id.startswith('AT'):
                attr_head(c,tile.x,yy,tile.w,e,i,reg);yy+=ht
            else:textrow(c,tile.x,yy,tile.w,e,ht,tile.kind,i,reg);yy+=ht
    # fill unoccupied ends with renglones for each column, never blank expanse
    for x in (14,109.7):
        relevant=[t.y+t.h for t in tiles if t.x==x or t.w>100]
        tail=max([39.0]+relevant)+2
        if tail<258:ruled(c,x,tail,92.2,int((259-tail)/6.5),6.5)

def spell_plan(spells):
    if not spells:return []
    pages=[];items=[];col=0;y=57;lvlast=None
    for lv in range(10):
        group=[e for e in spells if int(e.value)==lv]
        for e in group:
            if lv!=lvlast and y+7+6>259 or y+(7 if lv!=lvlast else 0)+5.55>259:
                col+=1;y=57;lvlast=None
                if col==3:pages.append(items);items=[];col=0
            if lv!=lvlast:items.append(('head',col,y,lv));y+=7.3
            items.append(('spell',col,y,e));y+=5.55;lvlast=lv
    if items:pages.append(items)
    return pages

def spells_page(c,f,part,reg,pn,total):
    frame(c,f.name,pn,total,'LISTA RÁPIDA DE CONJUROS',f.scenario)
    y=ribbon(c,14,34,187.9,'REFERENCIA MÁGICA','fuentes/estados ficticios')
    for i,(lbl,val) in enumerate([('APTITUD','INT'),('CD SALVACIÓN','15'),('ATAQUE MÁGICO','+7')]):
        statbox(c,14+i*63,y,61.5,10.5,lbl,val)
    cw=59.2
    bottom=[y+13]*3
    for kind,j,y,e in part:
        x=14+j*64.35
        if kind=='head':
            ruled(c,x,y,cw,1,7.3)
            text(c,x+1.3,y+5.1,'TRUCOS 0' if e==0 else f'NIVEL {e}',7.8,'Label','navy')
            if e!=0:
                # conservador: no fijar slots, mostrar renglón y cuadros físicos
                text(c,x+cw-25,y+5,'ESP. ___',6.0,'Label','deep')
                for k in range(3):box(c,x+cw-15+k*4.6,y+1.85,2.9)
        else:
            ruled(c,x,y,cw,1,5.55)
            # source shown as readable word (instead of invented CL/PREP strings)
            src=to_display(e.origin)
            box(c,x+.9,y+1.3,2.9)
            label=e.text
            text(c,x+4.6,y+3.75,label,fit(label,cw-17,'Body',6.8,5.7))
            text(c,x+cw-1.2,y+3.75,src,6.0,'Label','navy','right')
            reg.append(e.id)
        bottom[j]=max(bottom[j],y+(7.3 if kind=='head' else 5.55))
    for j in range(3):
        if bottom[j]<259:
            x=14+j*64.35;ruled(c,x,bottom[j],cw,int((259-bottom[j])/5.8),5.8)

def notes_parts(f):
    parts=[];part=[];y=43
    for e in f.notes:
        h=9+len(wrap(e.text,177,7.0))*4.1+3
        if part and y+h>257:parts.append(part);part=[];y=43
        part.append(e);y+=h
    if part:parts.append(part)
    return parts

def note_page(c,f,part,reg,pn,total):
    frame(c,f.name,pn,total,'NOTAS C-N3',f.scenario)
    y=ribbon(c,14,34,187.9,'NOTAS','solo notas digitales')
    for j,e in enumerate(part):
        lines=wrap(e.text,177,7.0)
        ht=10+len(lines)*4.1
        cart(c,14,y,187.9,ht)
        title=e.text.split(':')[0]
        text(c,17,y+5.2,title,8.0,'Label','deep')
        line(c,17,y+7.4,198,y+7.4)
        for i,s in enumerate(lines):text(c,17,y+11.1+i*4.1,s,7.0)
        reg.append(e.id);y+=ht+3
    if y<259:
        y=ribbon(c,14,y,187.9,'NOTAS MANUSCRITAS')
        ruled(c,14,y,187.9,int((259-y)/6.6),6.6)

def book_parts(f):
    parts=[];part=[];column=0;y=34
    for e in f.book:
        h=14+len(wrap(e.extra,86,6.7))*3.7+3
        if h>222:raise RuntimeError(f'Ficha libro excesiva {e.id}; pendiente división segura')
        if y+h>259:
            column+=1;y=34
            if column==2:parts.append(part);part=[];column=0
        part.append((column,y,e,h));y+=h+3
    if part:parts.append(part)
    return parts

def book_page(c,f,part,reg,pn,total):
    frame(c,f.name,pn,total,'LIBRO DE CONJUROS',f.scenario)
    for column,y,e,h in part:
        x=14+column*95.6;cart(c,x,y,92.3,h)
        rect(c,x+1.0,y+1,90.3,11,'pale',None)
        text(c,x+3,y+5.5,e.text,fit(e.text,72,'Hero',11.3,8.5),'Hero','deep')
        text(c,x+90,y+5.3,'NIVEL '+e.value,6.3,'Label','navy','right')
        text(c,x+3,y+10.0,e.origin.upper(),7.0,'Label','quiet')
        for i,s in enumerate(wrap(e.extra,86,6.7)):
            text(c,x+3,y+16.0+i*3.7,s,6.7)
        reg.append(e.id)

def final(c,f,pn,total):
    frame(c,f.name,pn,total,'NOTAS',f.scenario)
    yy=ribbon(c,14,34,187.9,'NOTAS')
    for j in range(2):ruled(c,14+j*95.7,yy,92.2,16,6.6)
    yy=yy+16*6.6+4.5
    yy=ribbon(c,14,yy,187.9,'NOTAS')
    gx,gy,gw,gh=14,yy,187.9,259-yy
    rect(c,gx,gy,gw,gh,None,'line',.45)
    for k in range(1,int(gw/5.5)+1):line(c,gx+k*5.5,gy,gx+k*5.5,gy+gh,'silver',.25)
    for k in range(1,int(gh/5.5)+1):line(c,gx,gy+k*5.5,gx+gw,gy+k*5.5,'silver',.25)

def build_plan(f,mode='auto'):
    alloc=allocations(f)
    if mode=='auto':
        options={m:pack_spills(alloc['spills'],m) for m in ('dos_columnas','mixto')}
        mode=min(options,key=lambda k:(options[k][1]['pages'],0 if k=='dos_columnas' else 1,-options[k][1]['occupied_pct']))
        comp={k:v[1] for k,v in options.items()}
    else:
        comp={mode:pack_spills(alloc['spills'],mode)[1]}
    c2pages,met=pack_spills(alloc['spills'],mode)
    allpages=[('p1',None),('p2',None),('p3',None)]+[('c2',x) for x in c2pages]+[('spells',p) for p in spell_plan(f.spells)]+[('notes',p) for p in notes_parts(f)]+[('book',p) for p in book_parts(f)]+[('final',None)]
    nav=collections.defaultdict(list)
    for idx,(tag,part) in enumerate(allpages,1):
        if tag=='c2':
            for tile in part:
                if idx not in nav[tile.kind]:nav[tile.kind].append(idx)
    return alloc,allpages,nav,mode,comp,met

def draw_nav(c,nav,kinds):
    # physical page numbers after final pagination; wrapped tiny cues above footer.
    cues=[MODULE[k]+' A P. '+','.join(str(q) for q in nav[k]) for k in kinds if nav.get(k)]
    if cues:
        t='   ·   '.join(cues)
        rect(c,14,259.3,187.9,4.6,'pale',None)
        text(c,15.0,262.7,t,fit(t,186,'Label',6.1,5.1),'Label','navy')

def render(f,path,mode='auto'):
    alloc,pages,nav,mode,compar,metrics=build_plan(f,mode)
    pdf=canvas.Canvas(str(path),pagesize=letter,pageCompression=1)
    pdf.setTitle('V9 INDEPENDIENTE CARTA '+f.name+' '+f.variant)
    reg=[]
    for idx,(kind,part) in enumerate(pages,1):
        if kind=='p1':frame(pdf,f.name,idx,len(pages),'VARIANTE '+f.variant,f.scenario);p1(pdf,f,alloc,reg);draw_nav(pdf,nav,['skill','attack','ammo'])
        elif kind=='p2':frame(pdf,f.name,idx,len(pages),'EQUIPO Y TESORO',f.scenario);p2(pdf,f,alloc,reg);draw_nav(pdf,nav,['equipment','coin','special','trait'])
        elif kind=='p3':frame(pdf,f.name,idx,len(pages),'TRASFONDO E HISTORIA',f.scenario);p3(pdf,f,alloc,reg);draw_nav(pdf,nav,['story'])
        elif kind=='c2':draw_c2(pdf,f,part,reg,idx,len(pages),nav,mode)
        elif kind=='spells':spells_page(pdf,f,part,reg,idx,len(pages))
        elif kind=='notes':note_page(pdf,f,part,reg,idx,len(pages))
        elif kind=='book':book_page(pdf,f,part,reg,idx,len(pages))
        else:final(pdf,f,idx,len(pages))
        pdf.showPage()
    pdf.save()
    expected=collections.Counter(f.full_ids);observed=collections.Counter(reg)
    return {'file':path.name,'variant':f.variant,'scenario':f.scenario,'pages':len(pages),
            'expected':len(expected),'drawn':len(reg),'missing':list((expected-observed).elements()),
            'duplicates':list((observed-expected).elements()),'c2':metrics,'candidate_c2':compar,'links':dict(nav),'mode':mode}

def comparator(f):
    path=OUT/'v9_comparador_C2_extremo.pdf'
    plans={m:build_plan(f,m) for m in ('dos_columnas','mixto')}
    allc2=[(mode,part) for mode,plan in plans.items() for kind,part in plan[1] if kind=='c2']
    c=canvas.Canvas(str(path),pagesize=letter);c.setTitle('V9 C2 comparación Carta')
    for i,(mode,part) in enumerate(allc2,1):draw_c2(c,f,part,[],i,len(allc2),{},mode,True);c.showPage()
    c.save()
    return {'file':path.name,'pages':len(allc2),'modes':{k:v[-1] for k,v in plans.items()}}

# ----- V10: owner-review changes, independent Letter-size prototype -----
V10_VERSION='10.0-CARTA-RECONSTRUIDA'
MODULE['skill']='ATRIBUTOS Y HABILIDADES'
ORIGINS['skill']='1'
RHEIGHT['skill']=5.1

V9_textrow=textrow
V9_spillheight=spillheight

def short_attr(name):
    return {'Fuerza':'FUE','Destreza':'DES','Constitución':'CON','Inteligencia':'INT','Sabiduría':'SAB','Carisma':'CAR','Suerte':'SUE','Cordura':'COR','Honor':'HON'}.get(name,''.join(x for x in name.upper() if x.isalpha())[:3])

def prepare_fixture(f):
    # Fixture-only annotation, not claiming these abbreviations are App fields.
    for a in f.attrs:
        for s in f.skillmap[a.text]:
            s.origin=short_attr(a.text)
            # Simplify fake compound labels: retain actual skill name + (STAT).
            if s.text.startswith(a.text+': '):s.text=s.text[len(a.text)+2:]
    return f

def identity(c,f):
    # PJ name appears ONLY once, on common page-1 header/membrete.
    cart(c,14,33,28,27)
    c.setFillColor(col('pale'));c.setStrokeColor(col('silver'))
    c.circle(M(28),PH-M(40.3),M(4.0),stroke=1,fill=1)
    c.ellipse(M(20.5),PH-M(56.6),M(35.5),PH-M(46.0),stroke=1,fill=1)
    text(c,28,59,'RETRATO',5.5,'Label','quiet','center')
    cart(c,45,33,156.9,12)
    text(c,47,37,'CLASE / NIVEL',6.2,'Label','quiet')
    text(c,47,42.1,'Maga exploradora / 8',9.3,'Body','ink')
    cart(c,45,47,52,13);text(c,47,51,'JUGADOR',5.9,'Label','quiet');text(c,47,56.5,'Personaje ficticio',7.2)
    cart(c,99,47,61.8,13);text(c,101,51,'RAZA',5.9,'Label','quiet');text(c,101,56.5,'Humana',7.4)
    cart(c,162.8,47,39.1,13);text(c,164.6,51,'ALINEAMIENTO',5.7,'Label','quiet');text(c,164.6,56.5,'Neutral',7.2)

def attr_head(c,x,y,w,a,i,registry,small=False):
    # Bigger score cartouche and modifier oval, both fully inside one ruled line.
    ht=8.05 if not small else 8.85
    ruled(c,x,y,w,1,ht,i)
    cart(c,x+0.9,y+1.25,15.2,6.4)
    text(c,x+8.5,y+6.15,a.value,11.0,'BodyBold','deep','center')
    c.setStrokeColor(col('navy'));c.setFillColor(col('white'));c.setLineWidth(.63)
    c.ellipse(M(x+17.3),PH-M(y+7.2),M(x+29.8),PH-M(y+2.1),stroke=1,fill=1)
    text(c,x+23.55,y+5.85,a.extra,8.7,'BodyBold','navy','center')
    text(c,x+31.5,y+4.1,a.text.upper(),fit(a.text,31.5,'Label',7.7,6.5),'Label','deep')
    text(c,x+31.5,y+7.4,'SALVACIÓN',6.1,'Label','quiet')
    box(c,x+w-14,y+3.0,3.1)
    text(c,x+w-1.6,y+6.0,a.extra,7.2,'BodyBold','navy','right')
    if registry is not None:registry.append(a.id)
    return ht

def textrow(c,x,y,w,value,h,kind,idx,registry=None):
    if kind=='skill':
        if value.id.startswith('__CTX_'):
            ruled(c,x,y,w,1,h,idx)
            text(c,x+2,y+3.5,'HABILIDADES DE '+value.text.upper(),7.3,'Label','deep')
            text(c,x+w-2,y+3.5,short_attr(value.text),7.1,'Label','navy','right')
            return
        ruled(c,x,y,w,1,h,idx)
        box(c,x+1.25,y+(h-3.0)/2,3.0)
        skill_name=value.text
        # No parent statistic printed inline => three-letter abbreviation mandatory.
        if value.origin and not skill_name.endswith('('+value.origin+')'):
            skill_name+=' ('+value.origin+')'
        sz=fit(skill_name,w-19.2,'Body',7.0,5.9)
        text(c,x+5.4,y+h*.7,skill_name,sz)
        text(c,x+w-1.4,y+h*.7,value.value,7.0,'BodyBold','navy','right')
        if registry is not None:registry.append(value.id)
        return
    if kind=='story':
        # Every printed narrative line shares the same physical ruled-paper cadence.
        lines=wrap(value.text,w-4.0,7.0)
        rh=6.0
        if len(lines)*rh>h+.1:raise ValueError('story text height under-planned: '+value.id)
        ruled(c,x,y,w,int(h/rh),rh,idx)
        for j,s in enumerate(lines):text(c,x+1.5,y+j*rh+4.6,s,7.0,'Body','ink')
        if registry is not None:registry.append(value.id)
        return
    if kind=='special':
        # Native-like continuous four-column ledger regardless of digital/manual population.
        ruled(c,x,y,w,1,h,idx)
        ax=.20*w;bx=.45*w;cx=.915*w
        for z in (ax,bx,cx):line(c,x+z,y,x+z,y+h,'line',.34)
        text(c,x+1.2,y+4.15,value.origin or '',fit(value.origin or '',ax-2.1,'Body',7.1,6.1),'Body','navy')
        text(c,x+ax+1.2,y+4.15,value.text,fit(value.text,bx-ax-2.4,'Body',6.9,5.7))
        arr=wrap(value.extra,cx-bx-2.4,6.6)
        if len(arr)*3.7>h-1.9:raise ValueError('special description overflow: '+value.id)
        for j,s in enumerate(arr):text(c,x+bx+1.2,y+4.05+j*3.7,s,6.6)
        box(c,x+cx+(w-cx)/2-1.55,y+(h-3.1)/2,3.1)
        if registry is not None:registry.append(value.id)
        return
    return V9_textrow(c,x,y,w,value,h,kind,idx,registry)

def allocations(f):
    prepare_fixture(f)
    res={'p1attrs':[],'p1skills':[],'p1attacks':f.attacks[:5],'p1traits':f.traits[:14], 'p1ammo':f.ammo[:2],
         'p2equip':f.equipment[:26], 'p2coins':f.coins[:10], 'p2traits':f.traits[14:58], 'p2special':f.special[:8],
         'p3story':[],'p3traits':[]}
    spills=collections.defaultdict(list)
    if f.variant=='A':
        y=72.6
        custom_overflow_started=False
        for i,a in enumerate(f.attrs):
            skills=f.skillmap[a.text]
            remaining=len(f.attrs)-i-1
            room=260.0-y-remaining*8.05
            if i>=6 and (custom_overflow_started or room<8.05+4.5):
                custom_overflow_started=True
                # Whole custom attribute + skills travel together, no lost IDs.
                spills['skill'].append(a)
                spills['skill']+=skills
                continue
            if room<8.05:raise RuntimeError('Six-classic attribute priority violated')
            count=max(0,min(len(skills),int((room-8.05+.001)/4.4)))
            res['p1attrs'].append((a,skills[:count]));y+=8.05+count*4.4
            if len(skills)>count:
                spills['skill'].append(Entry('__CTX_'+a.id,a.text))
                spills['skill']+=skills[count:]
    else:
        res['p1attrs']=[(a,[]) for a in f.attrs]
        # Two internal skill columns: preserve readable >=5mm lines and all basics.
        numrows=int((260.0-(72.6+len(f.attrs)*8.85+9.9))/5.2)
        ncols=2;cap=numrows*ncols
        skills=[e for a in f.attrs for e in f.skillmap[a.text]]
        res['p1skills']=skills[:cap]
        for a in f.attrs:
            remaining=[e for e in f.skillmap[a.text] if e in skills[cap:]]
            if remaining:
                spills['skill'].append(Entry('__CTX_'+a.id,a.text))
                spills['skill']+=remaining
    for k,full,slice_start in [('attack',f.attacks,5),('trait',f.traits,58),('ammo',f.ammo,2),
                               ('equipment',f.equipment,26),('coin',f.coins,10),('special',f.special,8)]:
        spills[k]+=full[slice_start:]
    # Page 3 story in TWO columns, after substantial writing space for background.
    storylines=[(e,wrap(e.text,88.0,7.0)) for e in f.story]
    top=125.6;row=6.0;maxrows=int((260.0-top)/row)
    cursor=0;colidx=0
    for e,lines in storylines:
        if cursor+len(lines)>maxrows:
            colidx+=1;cursor=0
        if colidx>=2:spills['story'].append(e)
        else:
            res['p3story'].append((e,colidx,cursor,len(lines)))
            cursor+=len(lines)+1 # one free writable rule between paragraphs
    res['spills']=spills
    return res

def p1(c,f,a,reg):
    identity(c,f)
    LX,LW,RX,RW=14,77.8,95.4,106.5
    y=ribbon(c,LX,63.8,LW,'ATRIBUTOS · '+f.variant)
    if f.variant=='A':
        for i,(at,skills) in enumerate(a['p1attrs']):
            y+=attr_head(c,LX,y,LW,at,i,reg)
            for j,e in enumerate(skills):textrow(c,LX,y,LW,e,4.4,'skill',j,reg);y+=4.4
    else:
        for i,(at,_) in enumerate(a['p1attrs']):y+=attr_head(c,LX,y,LW,at,i,reg,True)
        y=ribbon(c,LX,y+1.1,LW,'HABILIDADES','dos subcolumnas')
        skills=a['p1skills'];rowh=5.2;wc=(LW-1.2)/2;rows=math.ceil(len(skills)/2)
        for i,e in enumerate(skills):
            j=i//rows;k=i%rows
            textrow(c,LX+j*(wc+1.2),y+k*rowh,wc,e,rowh,'skill',k,reg)
        y+=rows*rowh
    if y<260.1:ruled(c,LX,y,LW,int((260.1-y)/5.0),5.0)
    # P1 right preserves V9 owner-approved composition.
    y=ribbon(c,RX,63.8,RW,'COMBATE Y SUPERVIVENCIA')
    stats=[('CA','16'),('INICIATIVA','+3'),('VELOCIDAD','9 m'),('COMPETENCIA','+3'),('INSPIRACIÓN',''),('DADOS DE GOLPE','8d8')]
    gw=(RW-2)/3
    for i,(lbl,val) in enumerate(stats):statbox(c,RX+(i%3)*(gw+1),y+(i//3)*11.1,gw,10.5,lbl,val)
    y+=23.3
    for i,(lbl,val) in enumerate([('PV ACTUALES','46'),('PV MÁXIMOS','50')]):statbox(c,RX+i*(RW/2),y,RW/2-1.1,11.,lbl,val)
    y+=12.1;y=ribbon(c,RX,y,RW,'ATAQUES')
    ruled(c,RX,y,RW,1,4.4)
    text(c,RX+1.5,y+3.25,'ARMA / ATAQUE / CONJURO',6.2,'Label','navy')
    text(c,RX+RW*.67,y+3.25,'BON.',6.,'Label','navy','center')
    text(c,RX+RW-1.5,y+3.25,'DAÑO / TIPO',6.,'Label','navy','right');y+=4.4
    for i in range(5):
        if i<len(a['p1attacks']):textrow(c,RX,y,RW,a['p1attacks'][i],5.2,'attack',i,reg)
        else:ruled(c,RX,y,RW,1,5.2,i)
        y+=5.2
    y+=1;y=ribbon(c,RX,y,RW,'RASGOS Y ATRIBUTOS','dos columnas')
    cw=(RW-2)/2
    for i in range(7):
        for j in range(2):
            ix=i+j*7;x=RX+j*(cw+2)
            if ix<len(a['p1traits']):textrow(c,x,y+i*5.1,cw,a['p1traits'][ix],5.1,'trait',i,reg)
            else:ruled(c,x,y+i*5.1,cw,1,5.1,i)
    y+=7*5.1+1.1;y=ribbon(c,RX,y,RW,'LANZAMIENTO DE CONJUROS')
    sw=(RW-2)/3
    for i,(lbl,val) in enumerate([('APTITUD MÁGICA','INT'),('CD SALVACIÓN','15'),('ATAQUE MÁGICO','+7')]):statbox(c,RX+i*(sw+1),y,sw,9.2,lbl,val)
    y+=10.5
    for row in range(3):
        for j in range(3):
            lv=row*3+j+1;cx=RX+j*(sw+1);cy=y+row*6.7
            ruled(c,cx,cy,sw,1,6.7,row+j);text(c,cx+1.8,cy+4.6,f'N{lv}',7.0,'Label','navy')
            for k in range(3):box(c,cx+12+k*6,cy+1.65,3.1)
    y+=20.7;y=ribbon(c,RX,y,RW,'MUNICIONES')
    if a['p1ammo']:
        for i,e in enumerate(a['p1ammo']):textrow(c,RX,y+i*12,RW,e,12,'ammo',i,reg)
        y+=12*len(a['p1ammo'])
    else:
        textrow(c,RX,y,RW,Entry('__manual__','Tipo: ___________________',value=''),12,'ammo',0,None);y+=12
    if y<260:ruled(c,RX,y,RW,int((260-y)/5.5),5.5)

def p2(c,f,a,reg):
    # Approved general structure unchanged: left 2-column Equipment + Treasure,
    # right 2-column Traits ALL the way to the Special Equipment ledger.
    LX,LW,RX,RW=14,91.3,109.1,92.8
    y=ribbon(c,LX,34.0,LW,'EQUIPO','OBJETO / CANTIDAD');tw=(LW-2)/2
    for i in range(13):
        for j in range(2):
            idx=i+j*13;x=LX+j*(tw+2)
            if idx<len(a['p2equip']):textrow(c,x,y+i*5.7,tw,a['p2equip'][idx],5.7,'equipment',i,reg)
            else:ruled(c,x,y+i*5.7,tw,1,5.7,i)
    y+=13*5.7+3;y=ribbon(c,LX,y,LW,'TESORO','denominación / cantidad');tw=(LW-2)/2
    for i in range(5):
        for j in range(2):
            idx=i+j*5;x=LX+j*(tw+2)
            if idx<len(a['p2coins']):textrow(c,x,y+i*7,tw,a['p2coins'][idx],7,'coin',i,reg)
            else:ruled(c,x,y+i*7,tw,1,7,i)
    ry=ribbon(c,RX,34,RW,'RASGOS Y ATRIBUTOS','mecánicos');twr=(RW-1.4)/2
    for i in range(22):
        for j in range(2):
            idx=i+j*22;x=RX+j*(twr+1.4)
            if idx<len(a['p2traits']):textrow(c,x,ry+i*5.65,twr,a['p2traits'][idx],5.65,'trait',i,reg)
            else:ruled(c,x,ry+i*5.65,twr,1,5.65,i)
    sy=ribbon(c,14,167.8,187.9,'EQUIPO ESPECIAL','ACTIVO: marcar a lápiz')
    ruled(c,14,sy,187.9,1,5.3)
    for z in (187.9*.20,187.9*.45,187.9*.915):line(c,14+z,sy,14+z,sy+5.3,'line',.34)
    text(c,15.4,sy+3.8,'UBICACIÓN',6.8,'Label','navy')
    text(c,14+187.9*.20+1.6,sy+3.8,'NOMBRE',6.8,'Label','navy')
    text(c,14+187.9*.45+1.6,sy+3.8,'DESCRIPCIÓN',6.8,'Label','navy')
    text(c,14+187.9*.915+1.0,sy+3.8,'ACTIVO',5.5,'Label','navy');sy+=5.3
    # 8 identical printed/manual ledger rows
    locs=['Cabeza','Rostro','Cuello','Mano izquierda','Mano derecha','Pecho','Piernas','Libre']
    for i in range(8):
        if i<len(a['p2special']):v=a['p2special'][i];textrow(c,14,sy+i*9.5,187.9,v,9.5,'special',i,reg)
        else:textrow(c,14,sy+i*9.5,187.9,Entry('__manual__','',origin=locs[i]),9.5,'special',i,None)

def p3(c,f,a,reg):
    # P3 entirely narrative (new owner instruction supersedes original P3 Traits).
    x,w=14,187.9;y=ribbon(c,x,34,w,'TRASFONDO Y PERFIL NARRATIVO')
    fields=[('TRASFONDO','Cartógrafa de los umbrales'),('RELIGIÓN / FE','Culto del faro'),
            ('RASGOS DE PERSONALIDAD','Observadora y paciente'),('IDEALES','La verdad precede a la gloria'),
            ('VÍNCULOS','Juramento con el grupo'),('DEFECTOS','Desconfía de los acertijos fáciles')]
    # 3 broad 24mm bands, 2 columns, label in first ruled line; data on second; two manual lines.
    fw=(w-2.0)/2
    for i,(lbl,val) in enumerate(fields):
        cx=x+(i%2)*(fw+2);cy=y+(i//2)*24
        ruled(c,cx,cy,fw,4,6.,i)
        text(c,cx+1.6,cy+4.4,lbl,7.0,'Label','deep')
        if f.story:text(c,cx+1.6,cy+10.4,val,fit(val,fw-3.0,'Body',7.3,6.3))
    hty=ribbon(c,x,y+3*24+2,w,'HISTORIA Y CRÓNICA')
    if abs(hty-125.6)>0.6:raise RuntimeError('P3 story baseline displaced '+str(hty))
    cw=(w-2.2)/2;ch=6.0;maxrows=int((260.0-hty)/ch)
    # Both columns fully ruled, with digital text on those lines.
    for j in range(2):ruled(c,x+j*(cw+2.2),hty,cw,maxrows,ch)
    for e,j,first,nlines in a['p3story']:
        cx=x+j*(cw+2.2);yy=hty+first*ch
        lines=wrap(e.text,cw-4,7.0)
        if len(lines)!=nlines:raise RuntimeError('P3 wrap planning mismatch: '+e.id)
        for k,s in enumerate(lines):text(c,cx+1.4,yy+k*ch+4.65,s,7.0)
        reg.append(e.id)

def spillheight(kind,e,w):
    if kind=='story':return max(6,len(wrap(e.text,w-4,7.0))*6.0)
    if kind=='skill' and (e.id.startswith('AT') or e.id.startswith('__CTX_')):return 8.05 if e.id.startswith('AT') else 6.8
    if kind=='special':return max(9.5,len(wrap(e.extra,w*.46-2.4,6.6))*3.7+2)
    return RHEIGHT[kind]

def make_tiles(spills,mode):
    tiles=[]
    for kind,items in spills.items():
        if not items:continue
        wide=kind=='special' or (mode=='mixto' and kind in ('attack','story'))
        width=187.9 if wide else 92.2
        # Group Equipment pairs into two side-by-side internal object/quantity subcolumns.
        if kind=='equipment':
            h=8.8+math.ceil(len(items)/2)*RHEIGHT['equipment']
            while items:
                maxcount=2*int((207-8.8)//RHEIGHT['equipment'])
                group=items[:maxcount];items=items[maxcount:]
                tiles.append(Tile(kind,group,w=width,h=8.8+math.ceil(len(group)/2)*RHEIGHT['equipment']))
            continue
        chunk=[];hh=8.8
        for e in items:
            eh=spillheight(kind,e,width)
            if chunk and hh+eh>207:
                tiles.append(Tile(kind,chunk,w=width,h=hh));chunk=[];hh=8.8
            if eh>203:raise RuntimeError('C2 single record too tall: '+e.id)
            chunk.append(e);hh+=eh
        if chunk:tiles.append(Tile(kind,chunk,w=width,h=hh))
    return tiles

def pack_spills(spills,mode):
    assert mode in ('dos_columnas','mixto')
    tiles=make_tiles(spills,mode);pages=[];active=[];ly=ry=37.5;num=0
    def end():
        nonlocal active,ly,ry,num
        if active:pages.append(active)
        active=[];ly=ry=37.5;num+=1
    for t in tiles:
        if t.w>100:
            yy=max(ly,ry)
            if yy+t.h>258.5:end();yy=37.5
            t.x=14;t.y=yy;t.w=187.9;ly=ry=yy+t.h+2
        else:
            if ly+t.h<=258.5:t.x,t.y=14,ly;ly+=t.h+2
            elif ry+t.h<=258.5:t.x,t.y=109.7,ry;ry+=t.h+2
            else:end();t.x,t.y=14,ly;ly+=t.h+2
        t.page=num;active.append(t)
    if active:pages.append(active)
    occ=sum(t.h*t.w for t in tiles)/(len(pages)*187.9*221) if pages else 0
    return pages,{'mode':mode,'pages':len(pages),'items':sum(len([e for e in t.entries if not e.id.startswith('__CTX_')]) for t in tiles),
                  'tiles':len(tiles),'occupied_pct':round(occ*100,1)}

def draw_c2(c,f,tiles,reg,pn,total,module_pages,mode,comparison=False):
    frame(c,f.name,pn,total,'CONTINUACIONES C2',f.scenario)
    text(c,14,35.3,'MÓDULOS COMPARTIDOS · '+mode.replace('_',' ').upper(),7.5,'Label','navy')
    for tile in tiles:
        yy=ribbon(c,tile.x,tile.y,tile.w,MODULE[tile.kind])
        if not comparison:
            related=module_pages.get(tile.kind,[])
            nav='VIENE P. '+ORIGINS[tile.kind]
            later=[z for z in related if z>pn]
            if later:nav+=' / SIG. '+str(later[0])
            text(c,tile.x+tile.w-2,tile.y+6,nav,6.1,'Label','navy','right')
        if tile.kind=='equipment':
            tw=(tile.w-1.4)/2;rows=math.ceil(len(tile.entries)/2)
            for j,e in enumerate(tile.entries):
                colnum=j//rows;rownum=j%rows
                textrow(c,tile.x+colnum*(tw+1.4),yy+rownum*RHEIGHT['equipment'],tw,e,RHEIGHT['equipment'],'equipment',rownum,reg)
            # missing rows still writable
            for j in range(len(tile.entries),rows*2):
                colnum=j//rows;rownum=j%rows
                ruled(c,tile.x+colnum*(tw+1.4),yy+rownum*RHEIGHT['equipment'],tw,1,RHEIGHT['equipment'],rownum)
        else:
            for i,e in enumerate(tile.entries):
                height=spillheight(tile.kind,e,tile.w)
                if tile.kind=='skill' and e.id.startswith('AT'):attr_head(c,tile.x,yy,tile.w,e,i,reg)
                else:textrow(c,tile.x,yy,tile.w,e,height,tile.kind,i,reg)
                yy+=height
    for x in (14,109.7):
        relevant=[t.y+t.h for t in tiles if t.x==x or t.w>100]
        tail=max([39]+relevant)+2
        if tail<258:ruled(c,x,tail,92.2,int((259-tail)/6.5),6.5)

def spell_plan(spells):
    if not spells:return []
    # All 0-9 levels have a labelled writable section even when no spells.
    entries=[]
    for lv in range(10):
        group=[e for e in spells if int(e.value)==lv]
        entries.append(('head',lv))
        entries.extend(('spell',e) for e in group)
        entries.append(('manual',None))
        if not group:entries.append(('manual',None))
    pages=[];items=[];col=0;y=57
    for kind,val in entries:
        height=7.3 if kind=='head' else 5.55
        if y+height>258:
            col+=1;y=57
            if col==3:pages.append(items);items=[];col=0
            if kind!='head':
                # continued level gets a real one-line header in next column
                level=last_level
                items.append(('head',col,y,level));y+=7.3
        if kind=='head':last_level=val
        items.append((kind,col,y,val));y+=height
    if items:pages.append(items)
    return pages

def spells_page(c,f,part,reg,pn,total):
    frame(c,f.name,pn,total,'LISTA RÁPIDA DE CONJUROS',f.scenario)
    y=ribbon(c,14,34,187.9,'REFERENCIA MÁGICA','fuentes ficticias')
    for i,(lbl,val) in enumerate([('APTITUD','INT'),('CD SALVACIÓN','15'),('ATAQUE MÁGICO','+7')]):statbox(c,14+i*63,y,61.5,10.5,lbl,val)
    cw=59.2;bottom=[y+13]*3
    for kind,j,yy,e in part:
        x=14+j*64.35
        if kind=='head':
            ruled(c,x,yy,cw,1,7.3)
            text(c,x+1.2,yy+5.0,'TRUCOS 0' if e==0 else f'NIVEL {e}',7.6,'Label','navy')
            if e!=0:
                text(c,x+cw-25,yy+5,'ESP. ___',5.9,'Label','deep')
                for k in range(3):box(c,x+cw-15+k*4.6,yy+1.85,2.9)
            bottom[j]=max(bottom[j],yy+7.3)
        elif kind=='manual':
            ruled(c,x,yy,cw,1,5.55)
            bottom[j]=max(bottom[j],yy+5.55)
        else:
            ruled(c,x,yy,cw,1,5.55)
            box(c,x+.9,yy+1.3,2.9)
            text(c,x+4.6,yy+3.75,e.text,fit(e.text,cw-17,'Body',6.8,5.7))
            text(c,x+cw-1.2,yy+3.75,to_display(e.origin),6.0,'Label','navy','right')
            reg.append(e.id)
            bottom[j]=max(bottom[j],yy+5.55)
    for j in range(3):
        if bottom[j]<259:
            x=14+j*64.35;ruled(c,x,bottom[j],cw,int((259-bottom[j])/5.8),5.8)

def final(c,f,pn,total):
    # SINGLE title 'NOTAS' in page heading; no second grid subtitle.
    frame(c,f.name,pn,total,'NOTAS',f.scenario)
    top=34;rowh=6.7;linecount=17;half=(187.9-3.4)/2
    for j in range(2):ruled(c,14+j*(half+3.4),top,half,linecount,rowh)
    gy=top+linecount*rowh+3.5;gw=187.9;gh=259-gy
    rect(c,14,gy,gw,gh,None,'line',.4)
    for k in range(1,int(gw/5.5)+1):line(c,14+k*5.5,gy,14+k*5.5,gy+gh,'silver',.25)
    for k in range(1,int(gh/5.5)+1):line(c,14,gy+k*5.5,14+gw,gy+k*5.5,'silver',.25)

def comparator(f):
    path=OUT/'v11_comparador_C2_extremo.pdf'
    plans={m:build_plan(f,m) for m in ('dos_columnas','mixto')}
    allc2=[(mode,part) for mode,plan in plans.items() for kind,part in plan[1] if kind=='c2']
    c=canvas.Canvas(str(path),pagesize=letter)
    c.setTitle('V11 C2 comparación en formato Carta')
    for i,(mode,part) in enumerate(allc2,1):draw_c2(c,f,part,[],i,len(allc2),{},mode,True);c.showPage()
    c.save()
    return {'file':path.name,'pages':len(allc2),'modes':{k:v[-1] for k,v in plans.items()}}

def render(f,path,mode='auto'):
    alloc,pages,nav,mode,compar,metrics=build_plan(f,mode)
    pdf=canvas.Canvas(str(path),pagesize=letter,pageCompression=1)
    pdf.setTitle('V11 · Carta · prototipo independiente · '+f.name+' · '+f.variant)
    reg=[]
    for idx,(kind,part) in enumerate(pages,1):
        if kind=='p1':frame(pdf,f.name,idx,len(pages),'VARIANTE '+f.variant,f.scenario);p1(pdf,f,alloc,reg);draw_nav(pdf,nav,['skill','attack','ammo'])
        elif kind=='p2':frame(pdf,f.name,idx,len(pages),'EQUIPO Y TESORO',f.scenario);p2(pdf,f,alloc,reg);draw_nav(pdf,nav,['equipment','coin','special','trait'])
        elif kind=='p3':frame(pdf,f.name,idx,len(pages),'TRASFONDO E HISTORIA',f.scenario);p3(pdf,f,alloc,reg);draw_nav(pdf,nav,['story'])
        elif kind=='c2':draw_c2(pdf,f,part,reg,idx,len(pages),nav,mode)
        elif kind=='spells':spells_page(pdf,f,part,reg,idx,len(pages))
        elif kind=='notes':note_page(pdf,f,part,reg,idx,len(pages))
        elif kind=='book':book_page(pdf,f,part,reg,idx,len(pages))
        else:final(pdf,f,idx,len(pages))
        pdf.showPage()
    pdf.save()
    expected=collections.Counter(f.full_ids);observed=collections.Counter(reg)
    return {'file':path.name,'variant':f.variant,'scenario':f.scenario,'pages':len(pages),'expected':len(expected),'drawn':len(reg),
            'missing':list((expected-observed).elements()),'duplicates':list((observed-expected).elements()),
            'c2':metrics,'candidate_c2':compar,'links':dict(nav),'mode':mode,
            'attr_on_p1':len(alloc['p1attrs']),'skill_on_p1':sum(len(x[1]) for x in alloc['p1attrs'])+len(alloc['p1skills']),
            'spill_group_attrs':[e.id for e in alloc['spills'].get('skill',[]) if e.id.startswith('AT')]}


# --- V11 OWNER-CORRECTION OVERRIDES ---
# V11: fixes from review, all owner-approved V10 structures otherwise retained.
V10_ribbon = ribbon
V10_allocations = allocations
V10_textrow = textrow
V10_draw_c2 = draw_c2
V10_final = final
V10_spell_plan = spell_plan
V10_spells_page = spells_page
_active_stat = None

def ribbon(c,x,y,w,title,subtitle=''):
    global _active_stat
    _active_stat=None
    return V10_ribbon(c,x,y,w,title,subtitle)

def attr_head(c,x,y,w,a,i,registry,small=False):
    global _active_stat
    _active_stat=short_attr(a.text)
    ht=8.05 if not small else 8.85
    ruled(c,x,y,w,1,ht,i)
    cart(c,x+.9,y+1.25,15.2,6.4)
    text(c,x+8.5,y+6.15,a.value,11.,'BodyBold','deep','center')
    c.setStrokeColor(col('navy'));c.setFillColor(col('white'));c.setLineWidth(.63)
    c.ellipse(M(x+17.3),PH-M(y+7.2),M(x+29.8),PH-M(y+2.1),stroke=1,fill=1)
    text(c,x+23.55,y+5.85,a.extra,8.7,'BodyBold','navy','center')
    # Saving throw label belongs to its box/bonus, not to the attribute name.
    text(c,x+31.3,y+4.45,a.text.upper(),fit(a.text,32,'Label',7.7,6.5),'Label','deep')
    text(c,x+w-30,y+7.55,'SALVACIÓN',5.85,'Label','quiet')
    box(c,x+w-14,y+2.7,3.1)
    text(c,x+w-1.4,y+5.8,a.extra,7.2,'BodyBold','navy','right')
    if registry is not None:registry.append(a.id)
    return ht

def textrow(c,x,y,w,value,h,kind,idx,registry=None):
    global _active_stat
    if kind=='skill':
        if value.id.startswith('__CTX_'):
            _active_stat=short_attr(value.text)
            ruled(c,x,y,w,1,h,idx)
            text(c,x+1.7,y+min(h-1.2,4.5),'HABILIDADES DE '+value.text.upper(),fit('HABILIDADES DE '+value.text.upper(),w-10,'Label',7.2,6.1),'Label','deep')
            return
        ruled(c,x,y,w,1,h,idx)
        box(c,x+1.25,y+(h-3)/2,3.)
        display=value.text
        # Three-letter suffix only if governing statistic is not in immediate visible context.
        if value.origin and value.origin!=_active_stat and not display.endswith('('+value.origin+')'):
            display+=' ('+value.origin+')'
        sz=fit(display,w-19.2,'Body',7.0,5.9)
        text(c,x+5.4,y+h*.7,display,sz)
        text(c,x+w-1.4,y+h*.7,value.value,7.0,'BodyBold','navy','right')
        if registry is not None:registry.append(value.id)
        return
    return V10_textrow(c,x,y,w,value,h,kind,idx,registry)

def allocations(f):
    # Conserve V10 allocation except remove the entirely unnecessary free ruled row
    # that separated consecutive digital history paragraphs.
    a=V10_allocations(f)
    a['p3story']=[]
    a['spills']['story']=[]
    row_capacity=int((260.0-125.6)/6.0)
    colidx=0;usedrows=0
    for e in f.story:
        lines=wrap(e.text,88.,7.)
        if usedrows+len(lines)>row_capacity:
            colidx+=1;usedrows=0
        if colidx<2:
            a['p3story'].append((e,colidx,usedrows,len(lines)))
            usedrows+=len(lines)  # no blank line, even across paragraph boundary
        else:
            a['spills']['story'].append(e)
    return a

def spell_plan(spells):
    if not spells:return []
    # Preserve all 10 level sections, including empty levels for handwriting.
    # Each section fits within a physical column in current fixtures.
    groups=[]
    for lv in range(10):
        es=[e for e in spells if int(e.value)==lv]
        base=7.3+5.55*(len(es)+1)
        if base>200.8:
            raise ValueError(f'Spell level {lv} exceeds full column; requires segmented level continuation fixture')
        groups.append((lv,es,base))
    pages=[];cursor=0;limit=200.8;top=57.0
    while cursor<len(groups):
        columns=[]
        for col in range(3):
            if cursor>=len(groups):break
            pending=groups[cursor:]
            available_cols=3-col
            target=min(limit,max(pending[0][2],sum(g[2] for g in pending)/available_cols))
            take=[];t=0
            while cursor<len(groups):
                candidate=groups[cursor]
                if take and t+candidate[2]>limit+1e-5:break
                if take and t>=target-.001:break
                # Favor reducing columns with excessive bottom whitespace, but preserve reading order.
                if take and abs(target-t)<abs(target-(t+candidate[2])) and available_cols>1:break
                take.append(candidate);t+=candidate[2];cursor+=1
            if not take:raise AssertionError('No spell group fits into column')
            columns.append((col,take,t))
        p=[]
        for col,chapters,used in columns:
            y=top
            # Allocate remaining height as whole manual rows among all represented levels.
            extra=max(0,int((limit-used+1e-5)//5.55))
            bylevel=[extra//len(chapters)]*len(chapters)
            for i in range(extra%len(chapters)):bylevel[i]+=1
            for idx,(lv,es,base) in enumerate(chapters):
                p.append(('head',col,round(y,3),lv));y+=7.3
                for e in es:
                    p.append(('spell',col,round(y,3),e));y+=5.55
                for _ in range(1+bylevel[idx]):
                    p.append(('manual',col,round(y,3),None));y+=5.55
            if y>258.01:raise ValueError(f'Spell col overflow {col}: {y}')
        pages.append(p)
    return pages

def spells_page(c,f,part,reg,pn,total):
    frame(c,f.name,pn,total,'LISTA RÁPIDA DE CONJUROS',f.scenario)
    y=ribbon(c,14,34,187.9,'REFERENCIA MÁGICA','fuentes ficticias')
    for i,(lbl,val) in enumerate([('APTITUD','INT'),('CD SALVACIÓN','15'),('ATAQUE MÁGICO','+7')]):
        statbox(c,14+i*63,y,61.5,10.5,lbl,val)
    cw=59.2
    for kind,j,yy,e in part:
        x=14+j*64.35
        if kind=='head':
            ruled(c,x,yy,cw,1,7.3)
            text(c,x+1.2,yy+5.,'TRUCOS 0' if e==0 else f'NIVEL {e}',7.6,'Label','navy')
            if e!=0:
                text(c,x+cw-25,yy+5,'ESP. ___',5.9,'Label','deep')
                for k in range(3):box(c,x+cw-15+k*4.6,yy+1.85,2.9)
        else:
            ruled(c,x,yy,cw,1,5.55)
            # Every physical line, including blank manual entries, is markable.
            box(c,x+.9,yy+1.3,2.9)
            if kind=='spell':
                text(c,x+4.6,yy+3.75,e.text,fit(e.text,cw-17,'Body',6.8,5.7))
                text(c,x+cw-1.2,yy+3.75,to_display(e.origin),6.0,'Label','navy','right')
                reg.append(e.id)

def full_grid(c,x,y,w,h,step=5.5):
    # Distribute grid equally so neither last row nor last column is clipped.
    nx=max(1,round(w/step));ny=max(1,round(h/step))
    rect(c,x,y,w,h,None,'line',.45)
    for k in range(1,nx):line(c,x+w*k/nx,y,x+w*k/nx,y+h,'silver',.27)
    for k in range(1,ny):line(c,x,y+h*k/ny,x+w,y+h*k/ny,'silver',.27)

def handwritten_notes(c,x,y,w,h):
    # Filler for a genuinely unused continuation area, not for digital Notes.
    if h<13:return False
    hh=6.9
    cart(c,x,y,w,hh,'pale')
    text(c,x+3.0,y+5.1,'NOTAS',7.6,'Label','deep')
    full_grid(c,x,y+hh,w,h-hh)
    return True

def draw_c2(c,f,tiles,reg,pn,total,module_pages,mode,comparison=False):
    frame(c,f.name,pn,total,'CONTINUACIONES C2',f.scenario)
    text(c,14,35.3,'MÓDULOS COMPARTIDOS · '+mode.replace('_',' ').upper(),7.5,'Label','navy')
    for tile in tiles:
        yy=ribbon(c,tile.x,tile.y,tile.w,MODULE[tile.kind])
        if not comparison:
            related=module_pages.get(tile.kind,[])
            nav='VIENE P. '+ORIGINS[tile.kind]
            later=[z for z in related if z>pn]
            if later:nav+=' / SIG. '+str(later[0])
            text(c,tile.x+tile.w-2,tile.y+6,nav,6.1,'Label','navy','right')
        if tile.kind=='equipment':
            tw=(tile.w-1.4)/2;rows=math.ceil(len(tile.entries)/2)
            for k,e in enumerate(tile.entries):
                column=k//rows;row=k%rows
                textrow(c,tile.x+column*(tw+1.4),yy+row*RHEIGHT['equipment'],tw,e,RHEIGHT['equipment'],'equipment',row,reg)
            for k in range(len(tile.entries),rows*2):
                column=k//rows;row=k%rows
                ruled(c,tile.x+column*(tw+1.4),yy+row*RHEIGHT['equipment'],tw,1,RHEIGHT['equipment'],row)
        else:
            for i,e in enumerate(tile.entries):
                hh=spillheight(tile.kind,e,tile.w)
                if tile.kind=='skill' and e.id.startswith('AT'):
                    attr_head(c,tile.x,yy,tile.w,e,i,reg)
                else:
                    textrow(c,tile.x,yy,tile.w,e,hh,tile.kind,i,reg)
                yy+=hh
    # Last unused space in each column is now labelled mini-NOTES graph paper.
    for x in (14,109.7):
        bottoms=[t.y+t.h for t in tiles if abs(t.x-x)<.1 or t.w>100]
        tail=max([39]+bottoms)+2
        if tail<258.4:handwritten_notes(c,x,tail,92.2,258.4-tail)

def final(c,f,pn,total):
    frame(c,f.name,pn,total,'NOTAS',f.scenario)
    top=34;rowh=6.7;linecount=17;half=(187.9-3.4)/2
    for j in range(2):ruled(c,14+j*(half+3.4),top,half,linecount,rowh)
    gy=top+linecount*rowh+3.5;gw=187.9;gh=259-gy
    full_grid(c,14,gy,gw,gh,5.5)

def comparator(f):
    path=OUT/'v11_comparador_C2_extremo.pdf'
    plans={m:build_plan(f,m) for m in ('dos_columnas','mixto')}
    allc2=[(mode,part) for mode,plan in plans.items() for kind,part in plan[1] if kind=='c2']
    c=canvas.Canvas(str(path),pagesize=letter)
    c.setTitle('V11 C2 comparación en Carta')
    for i,(mode,part) in enumerate(allc2,1):draw_c2(c,f,part,[],i,len(allc2),{},mode,True);c.showPage()
    c.save()
    return {'file':path.name,'pages':len(allc2),'modes':{k:v[-1] for k,v in plans.items()}}

# V11 pagination refinement: retain V10's reliable two-page extreme spell flow,
# but distribute every column's spare ruled space among its own levels.
V11_spells_page_preblank=spells_page

def spell_plan(spells):
    base=V10_spell_plan(spells)
    out=[]
    for part in base:
        current=[]
        for column in range(3):
            events=sorted([t for t in part if t[1]==column],key=lambda t:t[2])
            if not events:continue
            sections=[]
            for kind,_,yy,val in events:
                if kind=='head':sections.append((val,[]))
                elif sections:sections[-1][1].append((kind,val))
                else:raise AssertionError('Spell entry lacks physical level heading')
            baseheight=sum(7.3+5.55*len(lst) for _,lst in sections)
            extras=max(0,int((200.8-baseheight+1e-5)//5.55))
            perlevel=[extras//len(sections)]*len(sections)
            for j in range(extras%len(sections)):perlevel[j]+=1
            y=57.
            for j,(lv,entries) in enumerate(sections):
                current.append(('head',column,round(y,3),lv));y+=7.3
                for kind,v in entries:
                    current.append((kind,column,round(y,3),v));y+=5.55
                for k in range(perlevel[j]):
                    current.append(('manual',column,round(y,3),None));y+=5.55
            if y>258.01:raise AssertionError('V11 spell column overflow')
        out.append(current)
    return out

def spells_page(c,f,part,reg,pn,total):
    V11_spells_page_preblank(c,f,part,reg,pn,total)
    present={j for _,j,_,_ in part}
    for col_idx in range(3):
        if col_idx not in present:
            handwritten_notes(c,14+col_idx*64.35,57,59.2,201.0)

# Three-column ordinary spell sheets: balance contiguous level groups across ALL
# three columns; extreme sheets keep the proven two-page flow and use Notes only
# in genuinely unused columns.
V11_extreme_spell_plan=spell_plan

def spell_plan(spells):
    if not spells or len(spells)>40:return V11_extreme_spell_plan(spells)
    bylevel=[[e for e in spells if int(e.value)==lv] for lv in range(10)]
    weights=[7.3+5.55*(len(es)+1) for es in bylevel]
    options=[]
    for i in range(1,9):
        for j in range(i+1,10):
            lengths=[sum(weights[:i]),sum(weights[i:j]),sum(weights[j:])]
            if max(lengths)<=200.8:
                options.append((max(lengths)-min(lengths),max(lengths),i,j))
    if not options:return V11_extreme_spell_plan(spells)
    _,_,i,j=min(options)
    groups=[range(0,i),range(i,j),range(j,10)]
    result=[]
    for col,levs in enumerate(groups):
        levs=list(levs)
        base=sum(weights[lv] for lv in levs)
        extra=max(0,int((200.8-base+1e-5)//5.55))
        per=[extra//len(levs)]*len(levs)
        for r in range(extra%len(levs)):per[r]+=1
        y=57.
        for r,lv in enumerate(levs):
            result.append(('head',col,round(y,3),lv));y+=7.3
            for e in bylevel[lv]:
                result.append(('spell',col,round(y,3),e));y+=5.55
            for z in range(per[r]+1):
                result.append(('manual',col,round(y,3),None));y+=5.55
        if y>258.01:raise AssertionError('Ordinary spell col overflow')
    return [result]

if __name__=='__main__':
    scenarios=[]
    for cust,stress in [(2,False),(3,False),(3,True)]:
        for v in ('A','B'):
            scenario='extremo' if stress else f'ordinario_6mas{cust}'
            scenarios.append((f'v11_{scenario}_variante_{v}.pdf',mk_fixture(cust,stress,v)))
    empty=mk_fixture(0,False,'A');empty.scenario='CASI VACÍO · FICTICIO'
    for key in ('attacks','traits','ammo','equipment','coins','special','story','spells','notes','book'):setattr(empty,key,[])
    scenarios.insert(0,('v11_personaje_casi_vacio.pdf',empty))
    results=[]
    for name,f in scenarios:
        rr=render(f,OUT/name);results.append(rr)
        print(rr['file'], 'pages',rr['pages'],'ids',rr['drawn'],'/',rr['expected'],'missing',len(rr['missing']),'dup',len(rr['duplicates']),'C2',rr['c2']['pages'])
    results.append(comparator(scenarios[-2][1]))
    (HERE/'resultados_v11.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf8')
