#!/usr/bin/env python3
"""Independent structural/provenance QA for V10 synthesized Letter-size mockups.
Checks do not imply in-App fidelity, print legibility, owner visual approval.
"""
from pathlib import Path
import json, re, collections, math
import fitz
import v11_generador as gen
R=Path(__file__).resolve().parent
results=json.loads((R/'resultados_v11.json').read_text(encoding='utf8'))
checks=[]
def ck(cond,msg):checks.append({'ok':bool(cond),'test':msg})

def fixture_from_result(r):
    if 'comparador' in r['file']:return gen.mk_fixture(3,True,'A')
    v=r['variant'];name=r['file'];stress='extremo' in name
    if 'casi_vacio' in name:
        f=gen.mk_fixture(0,False,'A')
        for k in ('attacks','traits','ammo','equipment','coins','special','story','spells','notes','book'):setattr(f,k,[])
        f.scenario='CASI VACÍO · FICTICIO'
        return f
    custom=3 if '6mas3' in name or stress else 2
    return gen.mk_fixture(custom,stress,v)

for r in results:
    f=R/'pdfs'/r['file'];d=fitz.open(f)
    ck(d.page_count==r['pages'],f'{f.name}: physical page count')
    ck(all(abs(p.rect.width-612)<.1 and abs(p.rect.height-792)<.1 for p in d),f'{f.name}: all pages Letter 612×792pt')
    ck(not d.is_encrypted,f'{f.name}: readable and unencrypted')
    raw=[p.get_text() for p in d]
    ck(all('DUNGEONS' in t and '& DRAGONS' in t for t in raw),f'{f.name}: wordmark placeholder in every page')
    ck(all(('Mara de los Siete Umbrales' if 'extremo' in f.name else 'Ariadna del Alba') in t for t in raw),f'{f.name}: PC name in every membrete')
    ck(all('MAQUETA V11' not in t for t in [raw[-1]]),f'{f.name}: no sample footer on last handwritten page') if 'comparador' not in f.name else None
    if 'comparador' not in f.name:
        fixture=fixture_from_result(r)
        gen.prepare_fixture(fixture)
        ck(not r['missing'] and not r['duplicates'] and r['expected']==len(fixture.full_ids),f'{f.name}: IDs exact once against fixture')
        ck(raw[0].count(fixture.name)==1,f'{f.name}: P1 name occurs once')
        ck('CLASE / NIVEL' in raw[0],f'{f.name}: class field P1')
        ck('RASGOS PENDIENTES' not in raw[2],f'{f.name}: no mechanical Traits on P3')
        ck('HISTORIA Y CRÓNICA' in raw[2],f'{f.name}: story on P3')
        ck(raw[-1].count('NOTAS')==1,f'{f.name}: only one heading Notes on final page')
        ck(not any('CUADRÍCULA' in z.upper() for z in raw[-1:]),f'{f.name}: no grid-specific heading')
        ck('LISTA RÁPIDA DE CONJUROS' not in ''.join(raw) if not fixture.spells else 'LISTA RÁPIDA DE CONJUROS' in ''.join(raw),f'{f.name}: quick spells omitted iff empty')
        ck('NOTAS C-N3' not in ''.join(raw) if not fixture.notes else 'NOTAS C-N3' in ''.join(raw),f'{f.name}: notes C-N3 conditional')
        if fixture.spells:
            pages=[t for t in raw if 'LISTA RÁPIDA DE CONJUROS' in t]
            joined=' '.join(pages)
            for lv in range(10):
                key='TRUCOS 0' if lv==0 else f'NIVEL {lv}'
                ck(key in joined,f'{f.name}: reserved quick-spell level {lv}')
            ck('NIVEL 10' not in joined,f'{f.name}: no speculative epic spell levels')
        ck(not any('CL/PREP' in z or '/PREP' in z for z in raw),f'{f.name}: no rejected CL/PREP fabricated notation')
        ck('EQUIPO ESPECIAL' in raw[1] and 'TESORO' in raw[1],f'{f.name}: target P2 modules')
        ck(r['attr_on_p1']==(6 if 'casi_vacio' in f.name else (7 if ('extremo' in f.name and r['variant']=='A') else len(fixture.attrs))),f'{f.name}: P1 correct statistic capacity')
        if 'extremo' in f.name and r['variant']=='A':
            ck(r['spill_group_attrs']==['AT08','AT09'],f'{f.name}: genuine paired custom attribute+skills C2 overflow')
            ck('HONOR' in ''.join(raw[3:6]) and 'CORDURA' in ''.join(raw[3:6]),f'{f.name}: actual custom attribute headings on C2')
        if r['c2']['pages']:
            gen.prepare_fixture(fixture)
            plan,parts,nav,mode,opts,meta=gen.build_plan(fixture)
            for pagenum,(_,part) in enumerate(parts,1):
                if not isinstance(part,list) or (parts[pagenum-1][0]!='c2'):continue
                for tile in part:
                    if tile.kind=='special':ck(tile.w>180,f'{f.name}: Special Equipment C2 full page width')
                    if tile.kind=='equipment':ck(tile.w>80 and len(tile.entries)>0,f'{f.name}: Equipment C2 2 internal columns')
            for module,pages in r['links'].items():
                ck(all(4<=page<=len(d)-1 and 'MÓDULOS COMPARTIDOS' in raw[page-1] for page in pages),f'{f.name}: real physical C2 reference: {module}')
        # Source strings checks independent of ID count: each multiline story/book/notes fragment extracted.
        allraw=' '.join(raw)
        norm=lambda s:re.sub(r'\s+',' ',s).strip()
        normalized=norm(allraw)
        for e in fixture.story:
            for line in gen.wrap(e.text,88,7.):
                if len(line)>8:ck(norm(line) in normalized,f'{f.name}: story text fragment {e.id}')
        for e in fixture.book:
            for line in gen.wrap(e.extra,86,6.7):
                if len(line)>12:ck(norm(line) in normalized,f'{f.name}: Spellbook body fragment {e.id}')
        for e in fixture.notes:
            for line in gen.wrap(e.text,177,7.):
                if len(line)>12:ck(norm(line) in normalized,f'{f.name}: Notes body fragment {e.id}')
        if 'casi_vacio' in f.name:ck(d.page_count==4,f'{f.name}: empty has 3 bases + handwritten final')
    # Safety text bboxes inside physical sheet including footer, excluding a rendered fantasy glyph exceeding its bounding box.
    clip=[]
    for j,page in enumerate(d):
        for line in page.get_text('dict')['blocks']:
            if 'lines' not in line:continue
            for ln in line['lines']:
                for span in ln['spans']:
                    x0,y0,x1,y1=span['bbox']
                    if x0 < 26 or x1>586 or y0<23 or y1>770:
                        clip.append((j+1,span['text'][:30],tuple(round(t,1) for t in span['bbox'])))
    ck(not clip,f'{f.name}: text within paper safe margins (found {clip[:2]})')
    d.close()
passed=sum(c['ok'] for c in checks)
data={'passed':passed,'total':len(checks),'failed':[t for t in checks if not t['ok']],'checks':checks}
(R/'QA_V11.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
print('V11 QA',passed,'/',len(checks),'failures',len(data['failed']))
for x in data['failed'][:55]:print('FAIL:',x['test'])
